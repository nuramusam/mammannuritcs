    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html>
    <head>
    <title>Airshow :: Untitled</title>
    <style type="text/css">
    {}
    </style>
    <script>
    // Cross-browser utility function which returns a request object.
    function getXmlHttpRequest(){
    	var http_request = false;
    	try { http_request = new XMLHttpRequest(); }// Mozilla, Safari,...
    	catch(e) {
    		try { http_request = new ActiveXObject("Msxml2.XMLHTTP"); }
    		catch (e) {
    			try { http_request = new ActiveXObject("Microsoft.XMLHTTP"); }
    			catch (e) {};
    		}
    	}
    	return http_request;
    }
    function showEmail(s) { //s is the select element
    	var xhr = getXmlHttpRequest();
    	if(!xhr) {
    		alert("Cannot create XMLHTTP instance");
    		return false;
    	}
    	var c_id = s[s.selectedIndex].value;
    	s.disabled = true;//Prevent further ajax calls until response (or error) is received
    	var params = '?c_id=' + c_id;
    	var url = 'fetchCompanyEmail.php';
    	xhr.open('GET', url+params, true);
    	xhr.onreadystatechange = function() {
    		if (xhr.readyState == 4) {
    			if (xhr.status == 200 || xhr.status == 0) {//xhr.status == 0 is for testing with local files.
    				s.form.email_add.value = xhr.responseText;
    			}
    			else {
    				alert("Error in obtaining company email address");
    			}
    			s.disabled = false;
    		}
    	}
    	xhr.send(null);
    }
    </script>
    </head>
    <body>
    <!-- Must have a form tag -->
    <form>
    <select name="company_name" id="company_name" class="formfield" onChange="showEmail(this);">
    	<option value="">Please Select</option>
    	<option value="c_0">Company A</option>
    	<option value="c_1">Company B</option>
    	<option value="c_2">Company C</option>
    </select>
    <input name="email_add" id="email_add" type="text" size="40" value="">
    </form>
    </body>
    </html>