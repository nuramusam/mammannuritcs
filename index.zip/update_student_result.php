<?php require_once('Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE student SET admission_no=%s, full_name=%s, study_state=%s, study_center=%s, course=%s, semester=%s, `level`=%s, course_row1=%s, score_row1=%s, course_row2=%s, score_row2=%s, course_row3=%s, score_row3=%s, course_row4=%s, score_row4=%s, course_row5=%s, score_row5=%s, course_row6=%s, score_row6=%s, course_row7=%s, score_row7=%s, course_row8=%s, score_row8=%s, course_row9=%s, score_row9=%s, course_row10=%s, score_row10=%s, course_row11=%s, score_row11=%s, course_row12=%s, score_row12=%s, course_row13=%s, score_row13=%s, course_row14=%s, score_row14=%s, course_row15=%s, score_row15=%s, course_row16=%s, score_row16=%s, course_row17=%s, score_row17=%s, course_row18=%s, score_row18=%s, course_row19=%s, score_row19=%s, course_row20=%s, score_row20=%s, course_row21=%s, score_row21=%s, course_row22=%s, score_row22=%s, course_row23=%s, score_row23=%s, course_row24=%s, score_row24=%s, course_row25=%s, score_row25=%s, course_row26=%s, score_row26=%s, course_row27=%s, score_row27=%s, course_row28=%s, score_row28=%s, course_row29=%s, score_row29=%s, course_row30=%s, score_row30=%s WHERE id=%s",
                       GetSQLValueString($_POST['admission_no'], "text"),
                       GetSQLValueString($_POST['full_name'], "text"),
                       GetSQLValueString($_POST['study_state'], "text"),
                       GetSQLValueString($_POST['study_center'], "text"),
                       GetSQLValueString($_POST['course'], "text"),
                       GetSQLValueString($_POST['semester'], "text"),
                       GetSQLValueString($_POST['level'], "text"),
                       GetSQLValueString($_POST['course_row1'], "text"),
                       GetSQLValueString($_POST['score_row1'], "int"),
                       GetSQLValueString($_POST['course_row2'], "text"),
                       GetSQLValueString($_POST['score_row2'], "int"),
                       GetSQLValueString($_POST['course_row3'], "text"),
                       GetSQLValueString($_POST['score_row3'], "int"),
                       GetSQLValueString($_POST['course_row4'], "text"),
                       GetSQLValueString($_POST['score_row4'], "int"),
                       GetSQLValueString($_POST['course_row5'], "text"),
                       GetSQLValueString($_POST['score_row5'], "int"),
                       GetSQLValueString($_POST['course_row6'], "text"),
                       GetSQLValueString($_POST['score_row6'], "int"),
                       GetSQLValueString($_POST['course_row7'], "text"),
                       GetSQLValueString($_POST['score_row7'], "int"),
                       GetSQLValueString($_POST['course_row8'], "text"),
                       GetSQLValueString($_POST['score_row8'], "int"),
                       GetSQLValueString($_POST['course_row9'], "text"),
                       GetSQLValueString($_POST['score_row9'], "int"),
                       GetSQLValueString($_POST['course_row10'], "text"),
                       GetSQLValueString($_POST['score_row10'], "int"),
                       GetSQLValueString($_POST['course_row11'], "text"),
                       GetSQLValueString($_POST['score_row11'], "int"),
                       GetSQLValueString($_POST['course_row12'], "text"),
                       GetSQLValueString($_POST['score_row12'], "int"),
                       GetSQLValueString($_POST['course_row13'], "text"),
                       GetSQLValueString($_POST['score_row13'], "int"),
                       GetSQLValueString($_POST['course_row14'], "text"),
                       GetSQLValueString($_POST['score_row14'], "int"),
                       GetSQLValueString($_POST['course_row15'], "text"),
                       GetSQLValueString($_POST['score_row15'], "int"),
                       GetSQLValueString($_POST['course_row16'], "text"),
                       GetSQLValueString($_POST['score_row16'], "int"),
                       GetSQLValueString($_POST['course_row17'], "text"),
                       GetSQLValueString($_POST['score_row17'], "int"),
                       GetSQLValueString($_POST['course_row18'], "text"),
                       GetSQLValueString($_POST['score_row18'], "int"),
                       GetSQLValueString($_POST['course_row19'], "text"),
                       GetSQLValueString($_POST['score_row19'], "int"),
                       GetSQLValueString($_POST['course_row20'], "text"),
                       GetSQLValueString($_POST['score_row20'], "int"),
                       GetSQLValueString($_POST['course_row21'], "text"),
                       GetSQLValueString($_POST['score_row21'], "int"),
                       GetSQLValueString($_POST['course_row22'], "text"),
                       GetSQLValueString($_POST['score_row22'], "int"),
                       GetSQLValueString($_POST['course_row23'], "text"),
                       GetSQLValueString($_POST['score_row23'], "int"),
                       GetSQLValueString($_POST['course_row24'], "text"),
                       GetSQLValueString($_POST['score_row24'], "int"),
                       GetSQLValueString($_POST['course_row25'], "text"),
                       GetSQLValueString($_POST['score_row25'], "int"),
                       GetSQLValueString($_POST['course_row26'], "text"),
                       GetSQLValueString($_POST['score_row26'], "int"),
                       GetSQLValueString($_POST['course_row27'], "text"),
                       GetSQLValueString($_POST['score_row27'], "int"),
                       GetSQLValueString($_POST['course_row28'], "text"),
                       GetSQLValueString($_POST['score_row28'], "int"),
                       GetSQLValueString($_POST['course_row29'], "text"),
                       GetSQLValueString($_POST['score_row29'], "int"),
                       GetSQLValueString($_POST['course_row30'], "text"),
                       GetSQLValueString($_POST['score_row30'], "int"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_nti_ca, $nti_ca);
  $Result1 = mysql_query($updateSQL, $nti_ca) or die(mysql_error());

  $updateGoTo = "student_successfully_update.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_update_studentRecord = "-1";
if (isset($_GET['admission_no'])) {
  $colname_update_studentRecord = $_GET['admission_no'];
}
mysql_select_db($database_nti_ca, $nti_ca);
$query_update_studentRecord = sprintf("SELECT * FROM student WHERE admission_no = %s", GetSQLValueString($colname_update_studentRecord, "text"));
$update_studentRecord = mysql_query($query_update_studentRecord, $nti_ca) or die(mysql_error());
$row_update_studentRecord = mysql_fetch_assoc($update_studentRecord);
$totalRows_update_studentRecord = mysql_num_rows($update_studentRecord);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="index.html" class="current_page_item">HOME</a></li>
        <li><a href="tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap">
		    <p align="justify"><a href="admin_master_page.php">BACK TO MASTER PAGE</a>		    </p>
		    <form action="<?php echo $editFormAction; ?>" method="post" id="form1">
		      <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $row_update_studentRecord['id']; ?>" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Admission No:</td>
                  <td>&nbsp;</td>
                  <td><input name="admission_no" type="text" value="<?php echo htmlentities($row_update_studentRecord['admission_no'], ENT_COMPAT, 'utf-8'); ?>" size="15" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Student Name:</td>
                  <td>&nbsp;</td>
                  <td><input name="full_name" type="text" value="<?php echo htmlentities($row_update_studentRecord['full_name'], ENT_COMPAT, 'utf-8'); ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study State:</td>
                  <td>&nbsp;</td>
                  <td><input name="study_state" type="text" value="<?php echo htmlentities($row_update_studentRecord['study_state'], ENT_COMPAT, 'utf-8'); ?>" size="15" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study Center:</td>
                  <td>&nbsp;</td>
                  <td><input name="study_center" type="text" value="<?php echo htmlentities($row_update_studentRecord['study_center'], ENT_COMPAT, 'utf-8'); ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Course:</td>
                  <td>&nbsp;</td>
                  <td><input name="course" type="text" value="<?php echo htmlentities($row_update_studentRecord['course'], ENT_COMPAT, 'utf-8'); ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Semester:</td>
                  <td>&nbsp;</td>
                  <td><input name="semester" type="text" value="<?php echo htmlentities($row_update_studentRecord['semester'], ENT_COMPAT, 'utf-8'); ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Level:</td>
                  <td>&nbsp;</td>
                  <td><input name="level" type="text" value="<?php echo htmlentities($row_update_studentRecord['level'], ENT_COMPAT, 'utf-8'); ?>" size="10" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="right"><div id="wrapper">
<table align='center'>
<tr>
  <th bgcolor="#CCCCCC">&nbsp;</th>
<th bgcolor="#CCCCCC"><strong>COURSE CODE AND TITLE</strong></th>
<th bgcolor="#CCCCCC"><strong>SCORE</strong></th>
</tr>

<tr>
  <td>&nbsp;</td>
  <td><label for="course_row1"></label>
    <select name="course_row1" id="course_row1" title="<?php echo $row_update_studentRecord['course_row1']; ?>">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row1']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row6"></label>
    <input name="score_row1" type="text" id="score_row1" value="<?php echo $row_update_studentRecord['score_row1']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row4"></label>
    <select name="course_row2" id="course_row2">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row2']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row2"></label>
    <input name="score_row2" type="text" id="score_row2" value="<?php echo $row_update_studentRecord['score_row2']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row3"></label>
    <select name="course_row3" id="course_row3">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row3']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row3"></label>
    <input name="score_row3" type="text" id="score_row3" value="<?php echo $row_update_studentRecord['score_row3']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row4"></label>
    <select name="course_row4" id="course_row4">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row4']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row4"></label>
    <input name="score_row4" type="text" id="score_row4" value="<?php echo $row_update_studentRecord['score_row4']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row30"></label>
    <select name="course_row5" id="course_row5">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row5']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row5"></label>
    <input name="score_row5" type="text" id="score_row5" value="<?php echo $row_update_studentRecord['score_row5']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row6"></label>
    <select name="course_row6" id="course_row6">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row6']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row6"></label>
    <input name="score_row6" type="text" id="score_row6" value="<?php echo $row_update_studentRecord['score_row6']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row7"></label>
    <select name="course_row7" id="course_row7">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row7']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row7"></label>
    <input name="score_row7" type="text" id="score_row7" value="<?php echo $row_update_studentRecord['score_row7']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row8"></label>
    <select name="course_row8" id="course_row8">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row8']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row8"></label>
    <input name="score_row8" type="text" id="score_row8" value="<?php echo $row_update_studentRecord['score_row8']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row9"></label>
    <select name="course_row9" id="course_row9">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row9']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row9"></label>
    <input name="score_row9" type="text" id="score_row9" value="<?php echo $row_update_studentRecord['score_row9']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row10"></label>
    <select name="course_row10" id="course_row10">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row10']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row10"></label>
    <input name="score_row10" type="text" id="score_row10" value="<?php echo $row_update_studentRecord['score_row10']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row11"></label>
    <select name="course_row11" id="course_row11">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row11']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row11"></label>
    <input name="score_row11" type="text" id="score_row11" value="<?php echo $row_update_studentRecord['score_row11']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row12"></label>
    <select name="course_row12" id="course_row12">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row12']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row12"></label>
    <input name="score_row12" type="text" id="score_row12" value="<?php echo $row_update_studentRecord['score_row12']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row13"></label>
    <select name="course_row13" id="course_row13">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row13']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row13"></label>
    <input name="score_row13" type="text" id="score_row13" value="<?php echo $row_update_studentRecord['score_row13']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row14"></label>
    <select name="course_row14" id="course_row14">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row14']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row14"></label>
    <input name="score_row14" type="text" id="score_row14" value="<?php echo $row_update_studentRecord['score_row14']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row15"></label>
    <select name="course_row15" id="course_row15">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row15']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row15"></label>
    <input name="score_row15" type="text" id="score_row15" value="<?php echo $row_update_studentRecord['score_row15']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row16"></label>
    <select name="course_row16" id="course_row16">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row16']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row16"></label>
    <input name="score_row16" type="text" id="score_row16" value="<?php echo $row_update_studentRecord['score_row16']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row17"></label>
    <select name="course_row17" id="course_row17">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row17']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row17"></label>
    <input name="score_row17" type="text" id="score_row17" value="<?php echo $row_update_studentRecord['score_row17']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row18"></label>
    <select name="course_row18" id="course_row18">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row18']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row18"></label>
    <input name="score_row18" type="text" id="score_row18" value="<?php echo $row_update_studentRecord['score_row18']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row19"></label>
    <select name="course_row19" id="course_row19">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row19']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row19"></label>
    <input name="score_row19" type="text" id="score_row19" value="<?php echo $row_update_studentRecord['score_row19']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row20"></label>
    <select name="course_row20" id="course_row20">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row20']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row20"></label>
    <input name="score_row20" type="text" id="score_row20" value="<?php echo $row_update_studentRecord['score_row20']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row21"></label>
    <select name="course_row21" id="course_row21">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row21']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row21"></label>
    <input name="score_row21" type="text" id="score_row21" value="<?php echo $row_update_studentRecord['score_row21']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row22"></label>
    <select name="course_row22" id="course_row22">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row22']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row22"></label>
    <input name="score_row22" type="text" id="score_row22" value="<?php echo $row_update_studentRecord['score_row22']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row23"></label>
    <select name="course_row23" id="course_row23">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row23']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row23"></label>
    <input name="score_row23" type="text" id="score_row23" value="<?php echo $row_update_studentRecord['score_row23']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row24"></label>
    <select name="course_row24" id="course_row24">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row24']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row24"></label>
    <input name="score_row24" type="text" id="score_row24" value="<?php echo $row_update_studentRecord['score_row24']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row25"></label>
    <select name="course_row25" id="course_row25">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row25']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row25"></label>
    <input name="score_row25" type="text" id="score_row25" value="<?php echo $row_update_studentRecord['score_row25']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row26"></label>
    <select name="course_row26" id="course_row26">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row26']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row26"></label>
    <input name="score_row26" type="text" id="score_row26" value="<?php echo $row_update_studentRecord['score_row26']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row27"></label>
    <select name="course_row27" id="course_row27">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row27']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row27"></label>
    <input name="score_row27" type="text" id="score_row27" value="<?php echo $row_update_studentRecord['score_row27']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row28"></label>
    <select name="course_row28" id="course_row28">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row28']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row28"></label>
    <input name="score_row28" type="text" id="score_row28" value="<?php echo $row_update_studentRecord['score_row28']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row29"></label>
    <select name="course_row29" id="course_row29">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row29']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row29"></label>
    <input name="score_row29" type="text" id="score_row29" value="<?php echo $row_update_studentRecord['score_row29']; ?>" size="10" /></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><label for="course_row30"></label>
    <select name="course_row30" id="course_row30">
      <option value="" <?php if (!(strcmp("", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>> </option>
      <option value="EDU-101" <?php if (!(strcmp("EDU-101", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>EDU-101: Historical Foundation of Education</option>
      <option value="EDU-102" <?php if (!(strcmp("EDU-102", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>EDU-102: Sociological Foundation of Education</option>
      <option value="EDU-111" <?php if (!(strcmp("EDU-111", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>EDU-111: Educational Psychology: Child Development I</option>
      <option value="EDU-112" <?php if (!(strcmp("EDU-112", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>EDU-112: Educational Psychology: Child Development II</option>
      <option value="EDU-113" <?php if (!(strcmp("EDU-113", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>EDU-113: Educational Psychology: Child Development III</option>
      <option value="EDU-123" <?php if (!(strcmp("EDU-123", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>EDU-123: General Principle and Method I</option>
      <option value="EDU-124" <?php if (!(strcmp("EDU-124", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>EDU-124: General Principle and Method II</option>
      <option value="EDU-125" <?php if (!(strcmp("EDU-125", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>EDU-125: General Principles & Methodology of Teaching III</option>
      <option value="GSE-101" <?php if (!(strcmp("GSE-101", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>GSE-101: Oracy Skills</option>
      <option value="GSE-102" <?php if (!(strcmp("GSE-102", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>GSE-102: English Language Usage</option>
      <option value="GSE-103" <?php if (!(strcmp("GSE-103", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>GSE-103: Advanced Reading Skills</option>
      <option value="GSE-104" <?php if (!(strcmp("GSE-104", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>GSE-104: Advanced Writing Skills</option>
      <option value="GSE-105" <?php if (!(strcmp("GSE-105", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>GSE-105: Citizenship Educatio</option>
      <option value="GSE-106" <?php if (!(strcmp("GSE-106", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>GSE-106: Political Economy</option>
      <option value="GSE-111" <?php if (!(strcmp("GSE-111", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>GSE-111: Introduction to Computer Studies</option>
      <option value="PES-111" <?php if (!(strcmp("PES-111", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>PES-111: His. & Cultural Background of the Immediate Env.</option>
      <option value="PES-112" <?php if (!(strcmp("PES-112", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>PES-112: Drawing, Cultural and Creative Arts</option>
      <option value="PES-121" <?php if (!(strcmp("PES-121", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>PES-121: Primary Science Curriculum and Methods</option>
      <option value="PES-141" <?php if (!(strcmp("PES-141", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>PES-141: Number and Operations I</option>
      <option value="PES-142" <?php if (!(strcmp("PES-142", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>PES-142: Number and Operations II</option>
      <option value="CRS-101" <?php if (!(strcmp("CRS-101", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>CRS-101: Introduction to the Study of Religion</option>
      <option value="CRS-102" <?php if (!(strcmp("CRS-102", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>CRS-102: Critical Introduction of the Bible</option>
      <option value="CRS-111" <?php if (!(strcmp("CRS-111", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>CRS-111: Biblical World of the Old Testament</option>
      <option value="CRS-112" <?php if (!(strcmp("CRS-112", $row_update_studentRecord['course_row30']))) {echo "selected=\"selected\"";} ?>>CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row30"></label>
    <input name="score_row30" type="text" id="score_row30" value="<?php echo $row_update_studentRecord['score_row30']; ?>" size="10" /></td>
</tr>
</table>
</div></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input type="submit" class="Text_field_style" value="Update Result" /></td>
                </tr>
              </table>
              <input type="hidden" name="MM_update" value="form1" />
              <input type="hidden" name="id" value="<?php echo $row_update_studentRecord['id']; ?>" />
          </form>
            <p>&nbsp;</p>
            <h1 align="justify"><strong><font color="#FFF">Discover</font></strong></h1>
		    <p align="justify">This form. <a href="#">Read More..</a></p></div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
<?php
mysql_free_result($update_studentRecord);
?>
