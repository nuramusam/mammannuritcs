<?php require_once('Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_search_student = "-1";
if (isset($_GET['admission_no'])) {
  $colname_search_student = $_GET['admission_no'];
}
mysql_select_db($database_nti_ca, $nti_ca);
$query_search_student = sprintf("SELECT * FROM student WHERE admission_no = %s", GetSQLValueString($colname_search_student, "text"));
$search_student = mysql_query($query_search_student, $nti_ca) or die(mysql_error());
$row_search_student = mysql_fetch_assoc($search_student);
$totalRows_search_student = mysql_num_rows($search_student);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="index.html" class="current_page_item">HOME</a></li>
        <li><a href="tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap">
		    <p align="justify">The  form.</p>
		    <table width="100" border="1" align="center" cellpadding="7" cellspacing="7">
		      <tr>
		        <td><?php echo $row_search_student['admission_no']; ?></td>
		        <td><?php echo $row_search_student['full_name']; ?></td>
		        <td><?php echo $row_search_student['study_state']; ?></td>
	          </tr>
		      <tr>
		        <td>&nbsp;</td>
		        <td>&nbsp;</td>
		        <td><?php echo $row_search_student['study_center']; ?></td>
	          </tr>
		      <tr>
		        <td><?php echo $row_search_student['semester']; ?></td>
		        <td><?php echo $row_search_student['level']; ?></td>
		        <td><?php echo $row_search_student['course']; ?></td>
	          </tr>
	        </table>
		    <p align="justify">&nbsp;</p>
<h1 align="justify"><strong><font color="#FFF">Discover</font></strong></h1>
		    <p align="justify">This form. <a href="#">Read More..</a></p></div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
<?php
mysql_free_result($search_student);
?>
