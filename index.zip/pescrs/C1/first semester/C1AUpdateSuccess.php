<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="../../../images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="../../../style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="../../../index.html" class="current_page_item">HOME</a></li>
        <li><a href="../../../tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="../../../admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="../../../contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap">
		    <h3 align="center"><strong><font color="#FFF">Student Record Saved!</font></strong></h3>
<h1 align="justify">&nbsp;</h1>
<h3 align="center"><strong><font color="#FFF">Add Another Student Result</font></strong></h3><br />
<table width="500" border="0" align="center" cellpadding="2">
                    <tr>
                      <td align="right" class="Black_Color_Text">ADD STUDENT RESULT</td>
                      <td><form action="update_student_result.php" method="get" enctype="multipart/form-data" id="admission_no">
                        <input name="admission_no" type="text" id="admission_no" style="text-transform:uppercase" placeholder="NTI/NCE/2017/001" />
                        <input name="Update" type="submit" id="Update" value="Submit" />
                      </form></td>
              </tr>
                    <tr>
                      <td width="138" align="right" class="Black_Color_Text">SEARCH STUDENT RESULT</td>
                      <td width="346"><form action="C1ASearchStudent.php" method="get" enctype="multipart/form-data" name="id" target="_blank" id="admission_no">
                        <label for=""></label>
                        <input name="admission_no" type="text" id="admission_no" />
                        <input name="search" type="submit" id="serch" value="Submit" />
                      </form></td>
                    </tr>
            </table></p>
<p align="justify">&nbsp;</p>
<p align="justify"><a href="C1A.php" class="Text_Field">CLICK TO GO BACK TO PES/CRS HOME...</a></p>
          </div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
