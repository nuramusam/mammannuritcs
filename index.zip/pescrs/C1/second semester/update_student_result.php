<?php require_once('../../../Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE c1secondsemesterpescrs SET full_name=%s, study_state=%s, study_center=%s, course=%s, semester=%s, `level`=%s, course_row1=%s, score_row1=%s, course_row2=%s, score_row2=%s, course_row3=%s, score_row3=%s, course_row4=%s, score_row4=%s, course_row5=%s, score_row5=%s, course_row6=%s, score_row6=%s, course_row7=%s, score_row7=%s, course_row8=%s, score_row8=%s, course_row9=%s, score_row9=%s, course_row10=%s, score_row10=%s, course_row11=%s, score_row11=%s, course_row12=%s, score_row12=%s, course_row13=%s, score_row13=%s, course_row14=%s, score_row14=%s, course_row15=%s, score_row15=%s, course_row16=%s, score_row16=%s, course_row17=%s, score_row17=%s, course_row18=%s, score_row18=%s, course_row19=%s, score_row19=%s, course_row20=%s, score_row20=%s, course_row21=%s, score_row21=%s, course_row22=%s, score_row22=%s, course_row23=%s, score_row23=%s, course_row24=%s, score_row24=%s, course_row25=%s, score_row25=%s, course_row26=%s, score_row26=%s, course_row27=%s, score_row27=%s, course_row28=%s, score_row28=%s, course_row29=%s, score_row29=%s, course_row30=%s, score_row30=%s WHERE id=%s AND admission_no=%s",
                       GetSQLValueString($_POST['full_name'], "text"),
                       GetSQLValueString($_POST['study_state'], "text"),
                       GetSQLValueString($_POST['study_center'], "text"),
                       GetSQLValueString($_POST['course'], "text"),
                       GetSQLValueString($_POST['semester'], "text"),
                       GetSQLValueString($_POST['level'], "text"),
                       GetSQLValueString($_POST['course_row1'], "text"),
                       GetSQLValueString($_POST['score_row1'], "int"),
                       GetSQLValueString($_POST['course_row2'], "text"),
                       GetSQLValueString($_POST['score_row2'], "int"),
                       GetSQLValueString($_POST['course_row3'], "text"),
                       GetSQLValueString($_POST['score_row3'], "int"),
                       GetSQLValueString($_POST['course_row4'], "text"),
                       GetSQLValueString($_POST['score_row4'], "int"),
                       GetSQLValueString($_POST['course_row5'], "text"),
                       GetSQLValueString($_POST['score_row5'], "int"),
                       GetSQLValueString($_POST['course_row6'], "text"),
                       GetSQLValueString($_POST['score_row6'], "int"),
                       GetSQLValueString($_POST['course_row7'], "text"),
                       GetSQLValueString($_POST['score_row7'], "int"),
                       GetSQLValueString($_POST['course_row8'], "text"),
                       GetSQLValueString($_POST['score_row8'], "int"),
                       GetSQLValueString($_POST['course_row9'], "text"),
                       GetSQLValueString($_POST['score_row9'], "int"),
                       GetSQLValueString($_POST['course_row10'], "text"),
                       GetSQLValueString($_POST['score_row10'], "int"),
                       GetSQLValueString($_POST['course_row11'], "text"),
                       GetSQLValueString($_POST['score_row11'], "int"),
                       GetSQLValueString($_POST['course_row12'], "text"),
                       GetSQLValueString($_POST['score_row12'], "int"),
                       GetSQLValueString($_POST['course_row13'], "text"),
                       GetSQLValueString($_POST['score_row13'], "int"),
                       GetSQLValueString($_POST['course_row14'], "text"),
                       GetSQLValueString($_POST['score_row14'], "int"),
                       GetSQLValueString($_POST['course_row15'], "text"),
                       GetSQLValueString($_POST['score_row15'], "int"),
                       GetSQLValueString($_POST['course_row16'], "text"),
                       GetSQLValueString($_POST['score_row16'], "int"),
                       GetSQLValueString($_POST['course_row17'], "text"),
                       GetSQLValueString($_POST['score_row17'], "int"),
                       GetSQLValueString($_POST['course_row18'], "text"),
                       GetSQLValueString($_POST['score_row18'], "int"),
                       GetSQLValueString($_POST['course_row19'], "text"),
                       GetSQLValueString($_POST['score_row19'], "int"),
                       GetSQLValueString($_POST['course_row20'], "text"),
                       GetSQLValueString($_POST['score_row20'], "int"),
                       GetSQLValueString($_POST['course_row21'], "text"),
                       GetSQLValueString($_POST['score_row21'], "int"),
                       GetSQLValueString($_POST['course_row22'], "text"),
                       GetSQLValueString($_POST['score_row22'], "int"),
                       GetSQLValueString($_POST['course_row23'], "text"),
                       GetSQLValueString($_POST['score_row23'], "int"),
                       GetSQLValueString($_POST['course_row24'], "text"),
                       GetSQLValueString($_POST['score_row24'], "int"),
                       GetSQLValueString($_POST['course_row25'], "text"),
                       GetSQLValueString($_POST['score_row25'], "int"),
                       GetSQLValueString($_POST['course_row26'], "text"),
                       GetSQLValueString($_POST['score_row26'], "int"),
                       GetSQLValueString($_POST['course_row27'], "text"),
                       GetSQLValueString($_POST['score_row27'], "int"),
                       GetSQLValueString($_POST['course_row28'], "text"),
                       GetSQLValueString($_POST['score_row28'], "int"),
                       GetSQLValueString($_POST['course_row29'], "text"),
                       GetSQLValueString($_POST['score_row29'], "int"),
                       GetSQLValueString($_POST['course_row30'], "text"),
                       GetSQLValueString($_POST['score_row30'], "int"),
                       GetSQLValueString($_POST['hiddenField'], "int"),
                       GetSQLValueString($_POST['admission_no'], "text"));

  mysql_select_db($database_nti_ca, $nti_ca);
  $Result1 = mysql_query($updateSQL, $nti_ca) or die(mysql_error());

  $updateGoTo = "C1BUpdateSuccess.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_C1BupdatePesCrs = "-1";
if (isset($_GET['admission_no'])) {
  $colname_C1BupdatePesCrs = $_GET['admission_no'];
}
mysql_select_db($database_nti_ca, $nti_ca);
$query_C1BupdatePesCrs = sprintf("SELECT * FROM c1secondsemesterpescrs WHERE admission_no = %s", GetSQLValueString($colname_C1BupdatePesCrs, "text"));
$C1BupdatePesCrs = mysql_query($query_C1BupdatePesCrs, $nti_ca) or die(mysql_error());
$row_C1BupdatePesCrs = mysql_fetch_assoc($C1BupdatePesCrs);
$totalRows_C1BupdatePesCrs = mysql_num_rows($C1BupdatePesCrs);$colname_C1BupdatePesCrs = "-1";
if (isset($_GET['admission_no'])) {
  $colname_C1BupdatePesCrs = $_GET['admission_no'];
}
mysql_select_db($database_nti_ca, $nti_ca);
$query_C1BupdatePesCrs = sprintf("SELECT * FROM c1secondsemesterpescrs WHERE admission_no = %s", GetSQLValueString($colname_C1BupdatePesCrs, "text"));
$C1BupdatePesCrs = mysql_query($query_C1BupdatePesCrs, $nti_ca) or die(mysql_error());
$row_C1BupdatePesCrs = mysql_fetch_assoc($C1BupdatePesCrs);
$totalRows_C1BupdatePesCrs = mysql_num_rows($C1BupdatePesCrs);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="../../../images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="../../../style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="../../../index.html" class="current_page_item">HOME</a></li>
        <li><a href="../../../tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="../../../admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="../../../contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap">
<p align="justify"><font color="#FFF"><a href="../first semester/C1A.php" class="Text_Field">GO BACK...</a></font> </p>
<form action="<?php echo $editFormAction; ?>" method="post" id="form1">
  <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $row_C1BupdatePesCrs['id']; ?>" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Admission No:</td>
                  <td>&nbsp;</td>
                  <td><input name="admission_no" type="text" value="<?php echo $row_C1BupdatePesCrs['admission_no']; ?>" size="15" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Student Name:</td>
                  <td>&nbsp;</td>
                  <td><input name="full_name" type="text" value="<?php echo $row_C1BupdatePesCrs['full_name']; ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study State:</td>
                  <td>&nbsp;</td>
                  <td><input name="study_state" type="text" value="<?php echo $row_C1BupdatePesCrs['study_state']; ?>" size="15" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study Center:</td>
                  <td>&nbsp;</td>
                  <td><input name="study_center" type="text" value="<?php echo $row_C1BupdatePesCrs['study_center']; ?>" size="60" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Course:</td>
                  <td>&nbsp;</td>
                  <td><input name="course" type="text" value="<?php echo $row_C1BupdatePesCrs['course']; ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Semester:</td>
                  <td>&nbsp;</td>
                  <td><input name="semester" type="text" value="<?php echo $row_C1BupdatePesCrs['semester']; ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Level:</td>
                  <td>&nbsp;</td>
                  <td><input name="level" type="text" value="<?php echo $row_C1BupdatePesCrs['level']; ?>" size="10" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right" id="course_row26" name="course_row1" value="EDU-101">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                </table>
                  <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td colspan="3" align="center" id="course_row25" name="course_row1" value="EDU-101"><strong>EDUCATION COURSES</strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right" id="course_row1" name="course_row1" value="EDU-101">
                  <input name="course_row1" type="text" id="course_row1" title="EDU-121: Curriculum Studies I"  value="EDU-121" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td>
                  <input name="score_row1" type="text" id="score_row1" value="<?php echo $row_C1BupdatePesCrs['score_row1']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row2" type="text" id="course_row2" title="EDU-122: Curriculum Studies II" value="EDU-122" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row2" type="text" id="score_row2" value="<?php echo $row_C1BupdatePesCrs['score_row2']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row3" type="text" id="course_row3" title="EDU-126: Educational Technology I" value="EDU-126" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row3" type="text" id="score_row3" value="<?php echo $row_C1BupdatePesCrs['score_row3']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row4" type="text" id="course_row4" title="EDU-127: Educational Technology II" value="EDU-127" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row4" type="text" id="score_row4" value="<?php echo $row_C1BupdatePesCrs['score_row4']; ?>" size="5" /></td>
                </tr>
                </table>
                  <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td colspan="3" align="center">&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="center"><strong>GENERAL STUDIES EDUCATION COURSES</strong></td>
                  </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row9" type="text" id="course_row9" title="GSE-107: Science and Society" value="GSE-107" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row9" type="text" id="score_row9" value="<?php echo $row_C1BupdatePesCrs['score_row9']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row10" type="text" id="course_row10" title="GSE-108: Introduction to Library Studies" value="GSE-108" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row10" type="text" id="score_row10" value="<?php echo $row_C1BupdatePesCrs['score_row10']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row11" type="text" id="course_row11" title="GSE-109: Drama Minor" value="GSE-109" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row11" type="text" id="score_row11" value="<?php echo $row_C1BupdatePesCrs['score_row11']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row12" type="text" id="course_row12" title="GSE-110: Educational Development" value="GSE-110" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row12" type="text" id="score_row12" value="<?php echo $row_C1BupdatePesCrs['score_row12']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row13" type="text" id="course_row13" title="GSE-112: Instruction to Computer Studies II" value="GSE-112" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row13" type="text" id="score_row13" value="<?php echo $row_C1BupdatePesCrs['score_row13']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row14" type="text" id="course_row14" title="GSE-113: Basic General Mathematics" value="GSE-113" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row14" type="text" id="score_row14" value="<?php echo $row_C1BupdatePesCrs['score_row14']; ?>" size="5" /></td>
                </tr>
                </table>
                <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="center"><strong>PRIMARY EDUCATION STUDIES COURSES</strong></td>
                  </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row16" type="text" id="course_row16" title="PES-131: Primary English Curriculum and Methods I" value="PES-131" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row16" type="text" id="score_row16" value="<?php echo $row_C1BupdatePesCrs['score_row16']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row17" type="text" id="course_row17" title="PES-132: Primary English Curriculum and Methods II" value="PES-132" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row17" type="text" id="score_row17" value="<?php echo $row_C1BupdatePesCrs['score_row17']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row18" type="text" id="course_row18" title="PES-133: Speaking Skills" value="PES-133" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row18" type="text" id="score_row18" value="<?php echo $row_C1BupdatePesCrs['score_row18']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row19" type="text" id="course_row19" title="PES-151: Primary School Physical and Health Education Curriculum and Methods" value="PES-151" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row19" type="text" id="score_row19" value="<?php echo $row_C1BupdatePesCrs['score_row19']; ?>" size="5" /></td>
                </tr>
                </table>
                <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="center"><strong>CHRISTIAN RELIGIOUS STUDIES COURSES</strong></td>
                  </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row21" type="text" id="course_row21" title="CRS-113: Introduction to the Study of The Pentateuch" value="CRS-113" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row21" type="text" id="score_row21" value="<?php echo $row_C1BupdatePesCrs['score_row21']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row22" type="text" id="course_row22" title="CRS-114: History And Religion of Isreal" value="CRS-161" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row22" type="text" id="score_row22" value="<?php echo $row_C1BupdatePesCrs['score_row22']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row23" type="text" id="course_row23" title="CRS-111: Biblical World of the Old Testament" value="CRS-111" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row23" type="text" id="score_row23" value="<?php echo $row_C1BupdatePesCrs['score_row23']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
              </table>
                <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td><input name="button" type="submit" class="Text_Field" id="button" value="Save Result" /> <input name="button2" type="reset" class="Text_Field" id="button2" value="Reset" /></td>
                </tr>
              </table>
  <p>
    <input type="hidden" name="MM_update" value="form1" />
    <input type="hidden" name="admission_no" value="<?php echo $row_C1BupdatePesCrs['admission_no']; ?>" />
  </p>
</form>
<p>&nbsp;</p>

<p align="justify">&nbsp;</p>
          </div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
<?php
mysql_free_result($C1BupdatePesCrs);
?>
