<?php require_once('Connections/nti_ca.php'); ?><?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_DetailRS1 = 10;
$pageNum_DetailRS1 = 0;
if (isset($_GET['pageNum_DetailRS1'])) {
  $pageNum_DetailRS1 = $_GET['pageNum_DetailRS1'];
}
$startRow_DetailRS1 = $pageNum_DetailRS1 * $maxRows_DetailRS1;

$colname_DetailRS1 = "-1";
if (isset($_GET['recordID'])) {
  $colname_DetailRS1 = $_GET['recordID'];
}
mysql_select_db($database_nti_ca, $nti_ca);
$query_DetailRS1 = sprintf("SELECT * FROM student WHERE admission_no = %s", GetSQLValueString($colname_DetailRS1, "text"));
$query_limit_DetailRS1 = sprintf("%s LIMIT %d, %d", $query_DetailRS1, $startRow_DetailRS1, $maxRows_DetailRS1);
$DetailRS1 = mysql_query($query_limit_DetailRS1, $nti_ca) or die(mysql_error());
$row_DetailRS1 = mysql_fetch_assoc($DetailRS1);

if (isset($_GET['totalRows_DetailRS1'])) {
  $totalRows_DetailRS1 = $_GET['totalRows_DetailRS1'];
} else {
  $all_DetailRS1 = mysql_query($query_DetailRS1);
  $totalRows_DetailRS1 = mysql_num_rows($all_DetailRS1);
}
$totalPages_DetailRS1 = ceil($totalRows_DetailRS1/$maxRows_DetailRS1)-1;
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="index.html" class="current_page_item">HOME</a></li>
        <li><a href="tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap"><table border="1" align="center">
  <tr>
    <td>id</td>
    <td><?php echo $row_DetailRS1['id']; ?></td>
  </tr>
  <tr>
    <td>admission_no</td>
    <td><?php echo $row_DetailRS1['admission_no']; ?></td>
  </tr>
  <tr>
    <td>full_name</td>
    <td><?php echo $row_DetailRS1['full_name']; ?></td>
  </tr>
  <tr>
    <td>study_state</td>
    <td><?php echo $row_DetailRS1['study_state']; ?></td>
  </tr>
  <tr>
    <td>study_center</td>
    <td><?php echo $row_DetailRS1['study_center']; ?></td>
  </tr>
  <tr>
    <td>course</td>
    <td><?php echo $row_DetailRS1['course']; ?></td>
  </tr>
  <tr>
    <td>semester</td>
    <td><?php echo $row_DetailRS1['semester']; ?></td>
  </tr>
  <tr>
    <td>level</td>
    <td><?php echo $row_DetailRS1['level']; ?></td>
  </tr>
  <tr>
    <td>course_row1</td>
    <td><?php echo $row_DetailRS1['course_row1']; ?></td>
  </tr>
  <tr>
    <td>score_row1</td>
    <td><?php echo $row_DetailRS1['score_row1']; ?></td>
  </tr>
  <tr>
    <td>course_row2</td>
    <td><?php echo $row_DetailRS1['course_row2']; ?></td>
  </tr>
  <tr>
    <td>score_row2</td>
    <td><?php echo $row_DetailRS1['score_row2']; ?></td>
  </tr>
  <tr>
    <td>course_row3</td>
    <td><?php echo $row_DetailRS1['course_row3']; ?></td>
  </tr>
  <tr>
    <td>score_row3</td>
    <td><?php echo $row_DetailRS1['score_row3']; ?></td>
  </tr>
  <tr>
    <td>course_row4</td>
    <td><?php echo $row_DetailRS1['course_row4']; ?></td>
  </tr>
  <tr>
    <td>score_row4</td>
    <td><?php echo $row_DetailRS1['score_row4']; ?></td>
  </tr>
  <tr>
    <td>course_row5</td>
    <td><?php echo $row_DetailRS1['course_row5']; ?></td>
  </tr>
  <tr>
    <td>score_row5</td>
    <td><?php echo $row_DetailRS1['score_row5']; ?></td>
  </tr>
  <tr>
    <td>course_row6</td>
    <td><?php echo $row_DetailRS1['course_row6']; ?></td>
  </tr>
  <tr>
    <td>score_row6</td>
    <td><?php echo $row_DetailRS1['score_row6']; ?></td>
  </tr>
  <tr>
    <td>course_row7</td>
    <td><?php echo $row_DetailRS1['course_row7']; ?></td>
  </tr>
  <tr>
    <td>score_row7</td>
    <td><?php echo $row_DetailRS1['score_row7']; ?></td>
  </tr>
  <tr>
    <td>course_row8</td>
    <td><?php echo $row_DetailRS1['course_row8']; ?></td>
  </tr>
  <tr>
    <td>score_row8</td>
    <td><?php echo $row_DetailRS1['score_row8']; ?></td>
  </tr>
  <tr>
    <td>course_row9</td>
    <td><?php echo $row_DetailRS1['course_row9']; ?></td>
  </tr>
  <tr>
    <td>score_row9</td>
    <td><?php echo $row_DetailRS1['score_row9']; ?></td>
  </tr>
  <tr>
    <td>course_row10</td>
    <td><?php echo $row_DetailRS1['course_row10']; ?></td>
  </tr>
  <tr>
    <td>score_row10</td>
    <td><?php echo $row_DetailRS1['score_row10']; ?></td>
  </tr>
  <tr>
    <td>course_row11</td>
    <td><?php echo $row_DetailRS1['course_row11']; ?></td>
  </tr>
  <tr>
    <td>score_row11</td>
    <td><?php echo $row_DetailRS1['score_row11']; ?></td>
  </tr>
  <tr>
    <td>course_row12</td>
    <td><?php echo $row_DetailRS1['course_row12']; ?></td>
  </tr>
  <tr>
    <td>score_row12</td>
    <td><?php echo $row_DetailRS1['score_row12']; ?></td>
  </tr>
  <tr>
    <td>course_row13</td>
    <td><?php echo $row_DetailRS1['course_row13']; ?></td>
  </tr>
  <tr>
    <td>score_row13</td>
    <td><?php echo $row_DetailRS1['score_row13']; ?></td>
  </tr>
  <tr>
    <td>course_row14</td>
    <td><?php echo $row_DetailRS1['course_row14']; ?></td>
  </tr>
  <tr>
    <td>score_row14</td>
    <td><?php echo $row_DetailRS1['score_row14']; ?></td>
  </tr>
  <tr>
    <td>course_row15</td>
    <td><?php echo $row_DetailRS1['course_row15']; ?></td>
  </tr>
  <tr>
    <td>score_row15</td>
    <td><?php echo $row_DetailRS1['score_row15']; ?></td>
  </tr>
  <tr>
    <td>course_row16</td>
    <td><?php echo $row_DetailRS1['course_row16']; ?></td>
  </tr>
  <tr>
    <td>score_row16</td>
    <td><?php echo $row_DetailRS1['score_row16']; ?></td>
  </tr>
  <tr>
    <td>course_row17</td>
    <td><?php echo $row_DetailRS1['course_row17']; ?></td>
  </tr>
  <tr>
    <td>score_row17</td>
    <td><?php echo $row_DetailRS1['score_row17']; ?></td>
  </tr>
  <tr>
    <td>course_row18</td>
    <td><?php echo $row_DetailRS1['course_row18']; ?></td>
  </tr>
  <tr>
    <td>score_row18</td>
    <td><?php echo $row_DetailRS1['score_row18']; ?></td>
  </tr>
  <tr>
    <td>course_row19</td>
    <td><?php echo $row_DetailRS1['course_row19']; ?></td>
  </tr>
  <tr>
    <td>score_row19</td>
    <td><?php echo $row_DetailRS1['score_row19']; ?></td>
  </tr>
  <tr>
    <td>course_row20</td>
    <td><?php echo $row_DetailRS1['course_row20']; ?></td>
  </tr>
  <tr>
    <td>score_row20</td>
    <td><?php echo $row_DetailRS1['score_row20']; ?></td>
  </tr>
  <tr>
    <td>course_row21</td>
    <td><?php echo $row_DetailRS1['course_row21']; ?></td>
  </tr>
  <tr>
    <td>score_row21</td>
    <td><?php echo $row_DetailRS1['score_row21']; ?></td>
  </tr>
  <tr>
    <td>course_row22</td>
    <td><?php echo $row_DetailRS1['course_row22']; ?></td>
  </tr>
  <tr>
    <td>score_row22</td>
    <td><?php echo $row_DetailRS1['score_row22']; ?></td>
  </tr>
  <tr>
    <td>course_row23</td>
    <td><?php echo $row_DetailRS1['course_row23']; ?></td>
  </tr>
  <tr>
    <td>score_row23</td>
    <td><?php echo $row_DetailRS1['score_row23']; ?></td>
  </tr>
  <tr>
    <td>course_row24</td>
    <td><?php echo $row_DetailRS1['course_row24']; ?></td>
  </tr>
  <tr>
    <td>score_row24</td>
    <td><?php echo $row_DetailRS1['score_row24']; ?></td>
  </tr>
  <tr>
    <td>course_row25</td>
    <td><?php echo $row_DetailRS1['course_row25']; ?></td>
  </tr>
  <tr>
    <td>score_row25</td>
    <td><?php echo $row_DetailRS1['score_row25']; ?></td>
  </tr>
  <tr>
    <td>course_row26</td>
    <td><?php echo $row_DetailRS1['course_row26']; ?></td>
  </tr>
  <tr>
    <td>score_row26</td>
    <td><?php echo $row_DetailRS1['score_row26']; ?></td>
  </tr>
  <tr>
    <td>course_row27</td>
    <td><?php echo $row_DetailRS1['course_row27']; ?></td>
  </tr>
  <tr>
    <td>score_row27</td>
    <td><?php echo $row_DetailRS1['score_row27']; ?></td>
  </tr>
  <tr>
    <td>course_row28</td>
    <td><?php echo $row_DetailRS1['course_row28']; ?></td>
  </tr>
  <tr>
    <td>score_row28</td>
    <td><?php echo $row_DetailRS1['score_row28']; ?></td>
  </tr>
  <tr>
    <td>course_row29</td>
    <td><?php echo $row_DetailRS1['course_row29']; ?></td>
  </tr>
  <tr>
    <td>score_row29</td>
    <td><?php echo $row_DetailRS1['score_row29']; ?></td>
  </tr>
  <tr>
    <td>course_row30</td>
    <td><?php echo $row_DetailRS1['course_row30']; ?></td>
  </tr>
  <tr>
    <td>score_row30</td>
    <td><?php echo $row_DetailRS1['score_row30']; ?></td>
  </tr>
</table></div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html><?php
mysql_free_result($DetailRS1);
?>
