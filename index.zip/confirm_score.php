<?php require_once('Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_nti_ca, $nti_ca);
$query_Recordset1 = "SELECT * FROM student WHERE admission_no=(SELECT MAX(admission_no) FROM student)";
$Recordset1 = mysql_query($query_Recordset1, $nti_ca) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="index.html" class="current_page_item">HOME</a></li>
        <li><a href="tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap">
		    <p align="justify"><a href="student_successfully_update.php" class="Text_Field">SUBMIT SCORE</a></p>
<h1 align="justify"><strong><font color="#FFF">Please Confirm</font><font color="#FFF"> <?php echo $row_Recordset1['full_name']; ?> Record Before Submission...</font></strong></h1>
<p align="justify"><table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right"><strong>Admission No:</strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['admission_no']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong>Student Name:</strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['full_name']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong>Study State:</strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['study_state']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong>Study Center:</strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['study_center']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong>Course:</strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['course']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong>Semester:</strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['semester']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong>Level:</strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['level']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="right">&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="right">&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row1']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row1']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row2']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row2']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row3']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row3']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row4']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row4']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row5']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row5']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row6']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row6']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row7']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row7']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row8']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row8']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row9']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row9']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row10']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row10']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row11']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row11']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row12']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row12']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row13']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row13']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row14']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row14']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row15']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row15']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row16']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row16']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row17']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row17']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row18']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row18']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row19']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row19']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row20']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row20']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row21']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row21']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row22']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row22']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row23']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row23']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row24']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row24']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row25']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row25']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row26']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row26']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row27']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row27']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row28']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row28']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row29']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row29']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><strong><?php echo $row_Recordset1['course_row30']; ?></strong></td>
                  <td>&nbsp;</td>
                  <td><strong><?php echo $row_Recordset1['score_row30']; ?></strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                </table>
                </p>
	      <p align="justify">&nbsp;</p></div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
