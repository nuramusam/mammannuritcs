<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_grade = "localhost";
$database_grade = "grade";
$username_grade = "root";
$password_grade = "";
$grade = mysql_pconnect($hostname_grade, $username_grade, $password_grade) or trigger_error(mysql_error(),E_USER_ERROR); 
?>