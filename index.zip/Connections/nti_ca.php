<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_nti_ca = "localhost";
$database_nti_ca = "nti";
$username_nti_ca = "root";
$password_nti_ca = "";
$nti_ca = mysql_pconnect($hostname_nti_ca, $username_nti_ca, $password_nti_ca) or trigger_error(mysql_error(),E_USER_ERROR); 
?>