<?php require_once('Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_admin_master_page = 10;
$pageNum_admin_master_page = 0;
if (isset($_GET['pageNum_admin_master_page'])) {
  $pageNum_admin_master_page = $_GET['pageNum_admin_master_page'];
}
$startRow_admin_master_page = $pageNum_admin_master_page * $maxRows_admin_master_page;

mysql_select_db($database_nti_ca, $nti_ca);
$query_admin_master_page = "SELECT * FROM `user`";
$query_limit_admin_master_page = sprintf("%s LIMIT %d, %d", $query_admin_master_page, $startRow_admin_master_page, $maxRows_admin_master_page);
$admin_master_page = mysql_query($query_limit_admin_master_page, $nti_ca) or die(mysql_error());
$row_admin_master_page = mysql_fetch_assoc($admin_master_page);

if (isset($_GET['totalRows_admin_master_page'])) {
  $totalRows_admin_master_page = $_GET['totalRows_admin_master_page'];
} else {
  $all_admin_master_page = mysql_query($query_admin_master_page);
  $totalRows_admin_master_page = mysql_num_rows($all_admin_master_page);
}
$totalPages_admin_master_page = ceil($totalRows_admin_master_page/$maxRows_admin_master_page)-1;

$maxRows_student_Records = 10;
$pageNum_student_Records = 0;
if (isset($_GET['pageNum_student_Records'])) {
  $pageNum_student_Records = $_GET['pageNum_student_Records'];
}
$startRow_student_Records = $pageNum_student_Records * $maxRows_student_Records;

mysql_select_db($database_nti_ca, $nti_ca);
$query_student_Records = "SELECT * FROM student";
$query_limit_student_Records = sprintf("%s LIMIT %d, %d", $query_student_Records, $startRow_student_Records, $maxRows_student_Records);
$student_Records = mysql_query($query_limit_student_Records, $nti_ca) or die(mysql_error());
$row_student_Records = mysql_fetch_assoc($student_Records);

if (isset($_GET['totalRows_student_Records'])) {
  $totalRows_student_Records = $_GET['totalRows_student_Records'];
} else {
  $all_student_Records = mysql_query($query_student_Records);
  $totalRows_student_Records = mysql_num_rows($all_student_Records);
}
$totalPages_student_Records = ceil($totalRows_student_Records/$maxRows_student_Records)-1;

$queryString_admin_master_page = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_admin_master_page") == false && 
        stristr($param, "totalRows_admin_master_page") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_admin_master_page = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_admin_master_page = sprintf("&totalRows_admin_master_page=%d%s", $totalRows_admin_master_page, $queryString_admin_master_page);

$queryString_student_Records = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_student_Records") == false && 
        stristr($param, "totalRows_student_Records") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_student_Records = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_student_Records = sprintf("&totalRows_student_Records=%d%s", $totalRows_student_Records, $queryString_student_Records);
 if (!isset($_SESSION)) {
  session_start();
 }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Admin Page National Teachers' Institute, Kaduna</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script src="SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="index.html" class="current_page_item">HOME</a></li>
        <li><a href="tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <p align="center">&nbsp;</p>
		  <div class="current_page_item" id="calendar">
		    <div id="TabbedPanels1" class="TabbedPanels">
		      <ul class="TabbedPanelsTabGroup">
                <li class="TabbedPanelsTab" tabindex="0">ADMIN PAGE</li>
                <li class="TabbedPanelsTab" tabindex="0">USERS</li>
                <li class="TabbedPanelsTab" tabindex="0">TUTORS</li>
                <li class="TabbedPanelsTab" tabindex="0">STUDENT</li>
</ul>
		      <div class="TabbedPanelsContentGroup">
                <div class="TabbedPanelsContent">
                  <p>&nbsp;</p>
                  <table width="500" border="0" align="center" cellpadding="2">
                    <tr>
                      <td align="right" class="Black_Color_Text">UPDATE ADMIN</td>
                      <td><form action="update_student_result.php" method="get" enctype="multipart/form-data" name="id" id="admission_no">
                        <input type="text" />
                        <input name="id" type="submit" id="id" value="Submit" />
                      </form></td>
                    </tr>
                    <tr>
                      <td align="right" class="Black_Color_Text">DELETE ADMIN</td>
                      <td><form action="" method="get" name="id" id="id">
                        <label for=""></label>
                        <input type="text" />
                        <input type="submit" name="delete" id="delete" value="Submit" />
                      </form></td>
                    </tr>
                    <tr>
                      <td width="138" align="right" class="Black_Color_Text">SEARCH ADMIN</td>
                      <td width="346"><form action="search admin.php" method="get" name="id" id="id">
                        <label for=""></label>
                        <input name="id" type="text" id="id" />
                        <input name="search" type="submit" id="serch" value="Submit" />
                      </form></td>
                    </tr>
                  </table>
                  <p>&nbsp;</p>
                </div>
                <div class="TabbedPanelsContent">
                  <p>&nbsp;</p>
                  <table border="1">
                    <tr>
                      <td bgcolor="#333300"><strong>Serial No.</strong></td>
                      <td bgcolor="#333300"><strong>USERNAME</strong></td>
                      <td bgcolor="#333300"><strong>FIRST NAME</strong></td>
                      <td bgcolor="#333300"><strong>SURNAME</strong></td>
                      <td bgcolor="#333300"><strong>USER TYPE</strong></td>
                      <td bgcolor="#333300"><strong>PASSWORD</strong></td>
                      <td bgcolor="#333300"><strong>CREATED AT</strong></td>
                      <td bgcolor="#333300"><strong>UPDATED AT</strong></td>
                    </tr>
                    <?php do { ?>
                    <tr>
                      <td><a href="admin_master_preview.php?recordID=<?php echo $row_admin_master_page['id']; ?>"> 000<?php echo $row_admin_master_page['id']; ?>&nbsp; </a></td>
                      <td><?php echo $row_admin_master_page['username']; ?>&nbsp; </td>
                      <td><?php echo $row_admin_master_page['first_name']; ?>&nbsp; </td>
                      <td><?php echo $row_admin_master_page['last_name']; ?>&nbsp; </td>
                      <td><?php echo $row_admin_master_page['user_type']; ?>&nbsp; </td>
                      <td><?php echo $row_admin_master_page['password']; ?>&nbsp; </td>
                      <td><?php echo $row_admin_master_page['created_at']; ?>&nbsp; </td>
                      <td><?php echo $row_admin_master_page['updated_at']; ?>&nbsp; </td>
                    </tr>
                    <?php } while ($row_admin_master_page = mysql_fetch_assoc($admin_master_page)); ?>
                  </table>
                  <br />
                  <table border="0" align="center">
                    <tr>
                      <td><?php if ($pageNum_admin_master_page > 0) { // Show if not first page ?>
                        <a href="<?php printf("%s?pageNum_admin_master_page=%d%s", $currentPage, 0, $queryString_admin_master_page); ?>">First</a>
                      <?php } // Show if not first page ?></td>
                      <td><?php if ($pageNum_admin_master_page > 0) { // Show if not first page ?>
                        <a href="<?php printf("%s?pageNum_admin_master_page=%d%s", $currentPage, max(0, $pageNum_admin_master_page - 1), $queryString_admin_master_page); ?>">Previous</a>
                      <?php } // Show if not first page ?></td>
                      <td><?php if ($pageNum_admin_master_page < $totalPages_admin_master_page) { // Show if not last page ?>
                        <a href="<?php printf("%s?pageNum_admin_master_page=%d%s", $currentPage, min($totalPages_admin_master_page, $pageNum_admin_master_page + 1), $queryString_admin_master_page); ?>">Next</a>
                      <?php } // Show if not last page ?></td>
                      <td><?php if ($pageNum_admin_master_page < $totalPages_admin_master_page) { // Show if not last page ?>
                        <a href="<?php printf("%s?pageNum_admin_master_page=%d%s", $currentPage, $totalPages_admin_master_page, $queryString_admin_master_page); ?>">Last</a>
                      <?php } // Show if not last page ?></td>
                    </tr>
                  </table>
                  <center>
                    Records Pages <br />
                    <?php echo ($startRow_admin_master_page + 1) ?> to <?php echo min($startRow_admin_master_page + $maxRows_admin_master_page, $totalRows_admin_master_page) ?> of <?php echo $totalRows_admin_master_page ?>
                  </center>
                </div>
                <div class="TabbedPanelsContnt">
                
                <table width="500" border="0" align="center" cellpadding="2">
                    <tr>
                      <td align="right" class="Black_Color_Text">ADD STUDENT RESULT</td>
                      <td><form action="update_student_result.php" method="get" enctype="multipart/form-data" id="admission_no">
                        <input name="admission_no" type="text" id="admission_no" />
                        <input name="Update" type="submit" id="Update" value="Submit" />
                      </form></td>
                    </tr>
                    <tr>
                      <td align="right" class="Black_Color_Text">DELETE STUDENT</td>
                      <td><form action="" method="get" name="id" id="id">
                        <label for=""></label>
                        <input type="text" />
                        <input type="submit" name="delete" id="delete" value="Submit" />
                      </form></td>
                    </tr>
                    <tr>
                      <td width="138" align="right" class="Black_Color_Text">SEARCH STUDENT RESULT</td>
                      <td width="346"><form action="search_student.php" method="get" enctype="multipart/form-data" name="id" id="admission_no">
                        <label for=""></label>
                        <input name="admission_no" type="text" id="admission_no" />
                        <input name="search" type="submit" id="serch" value="Submit" />
                      </form></td>
                    </tr>
                  </table></div>
                <div class="TabbedPanelsContent"><br /><strong><center>LIST OF STUDENT ADDED BY DESK OFFICER OF EACH STUDY CENTER</center></strong>
<p>&nbsp;</p>
<table border="1" cellpadding="2" cellspacing="2">
                    <tr>
                      <th bgcolor="#666666"><strong>ID</strong></th>
                      <th nowrap="nowrap" bgcolor="#666666"><strong>ADMISSION NUMBER</strong></th>
                      <th nowrap="nowrap" bgcolor="#666666"><strong>NAMES</strong></th>
                      <th nowrap="nowrap" bgcolor="#666666"><strong>STATES</strong></th>
                      <th nowrap="nowrap" bgcolor="#666666"><strong>CENTERS</strong></th>
                      <th nowrap="nowrap" bgcolor="#666666"><strong>COURSE</strong></th>
                      <th nowrap="nowrap" bgcolor="#666666"><strong>LEVEL</strong></th>
                      <th nowrap="nowrap" bgcolor="#666666"><strong>SEMESTER</strong></th>
                    </tr>
                    <?php do { ?>
                      <tr>
                        <td><strong><?php echo $row_student_Records['id']; ?>&nbsp; </strong></td>
                        <td bgcolor="#FFFFFF"><strong><a href="student_Records.php?recordID=<?php echo $row_student_Records['admission_no']; ?>"> <?php echo $row_student_Records['admission_no']; ?>&nbsp; </a></strong></td>
                        <td><?php echo $row_student_Records['full_name']; ?>&nbsp; </td>
                        <td><?php echo $row_student_Records['study_state']; ?>&nbsp; </td>
                        <td><?php echo $row_student_Records['study_center']; ?>&nbsp; </td>
                        <td><?php echo $row_student_Records['course']; ?>&nbsp; </td>
                        <td><?php echo $row_student_Records['level']; ?>&nbsp; </td>
                        <td><?php echo $row_student_Records['semester']; ?>&nbsp; </td>
                      </tr>
                      <?php } while ($row_student_Records = mysql_fetch_assoc($student_Records)); ?>
                  </table>
                  <br />
                  <table border="0">
                    <tr>
                      <td><?php if ($pageNum_student_Records > 0) { // Show if not first page ?>
                          <a href="<?php printf("%s?pageNum_student_Records=%d%s", $currentPage, 0, $queryString_student_Records); ?>">First</a>
                      <?php } // Show if not first page ?></td>
                      <td><?php if ($pageNum_student_Records > 0) { // Show if not first page ?>
                          <a href="<?php printf("%s?pageNum_student_Records=%d%s", $currentPage, max(0, $pageNum_student_Records - 1), $queryString_student_Records); ?>">Previous</a>
                      <?php } // Show if not first page ?></td>
                      <td><?php if ($pageNum_student_Records < $totalPages_student_Records) { // Show if not last page ?>
                          <a href="<?php printf("%s?pageNum_student_Records=%d%s", $currentPage, min($totalPages_student_Records, $pageNum_student_Records + 1), $queryString_student_Records); ?>">Next</a>
                      <?php } // Show if not last page ?></td>
                      <td><?php if ($pageNum_student_Records < $totalPages_student_Records) { // Show if not last page ?>
                          <a href="<?php printf("%s?pageNum_student_Records=%d%s", $currentPage, $totalPages_student_Records, $queryString_student_Records); ?>">Last</a>
                      <?php } // Show if not last page ?></td>
                    </tr>
                  </table>
Records <?php echo ($startRow_student_Records + 1) ?> to <?php echo min($startRow_student_Records + $maxRows_student_Records, $totalRows_student_Records) ?> of <?php echo $totalRows_student_Records ?></div>
</div>
	        </div>
		    <p>&nbsp;</p>
            </div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->

    <p>&nbsp;</p>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1", {defaultTab:3});
    </script>
</body>
</html>
<?php
mysql_free_result($admin_master_page);

mysql_free_result($student_Records);
?>
