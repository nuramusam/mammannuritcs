<!doctype html>
<html>

<head>
<title>Adding dynamic field - FormValidation</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link href="css/c588c3c0468f4633c99de6e16289c863.css" rel="stylesheet" type="text/css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/0a3b9034e109d88d72f83c9e6c9d13b7.js"></script>
</head>


<body class="demo-bootstrap">
    <div class="container">
        <div class="row">
            <div class="col-xs-12" id="demoContainer" style="height: auto">
                <form id="courseForm" method="post" class="form-horizontal">
    <div class="form-group">
        <label class="col-xs-1 control-label">COURSE</label>
        <div class="col-xs-4">
        
        <select  class="form-control" name="course[0].course">
            <option>--Select Course Code--</option>
            <option value="EDU-431">EDU-431:Guidance and Counselling I</option>
            <option value="EDU-432">EDU-432:Guidance and Counselling II</option>
            <option value="EDU-411">EDU-411:Education for People with Special Needs</option>
            <option value="EDU-412">EDU-412:Teaching Practice II</option>
            <option value="EDU-413">EDU-413:Project</option>
            </select>
        </div>
        <div class="col-xs-2">
            <input type="text" class="form-control" name="course[0].score" placeholder="Score" />
        </div>
        <div class="col-xs-1">
            <button type="button" class="btn btn-default addButton"><i class="fa fa-plus"></i></button>
        </div>
    </div>

    <!-- The template for adding new field -->
    <div class="form-group hide" id="courseTemplate">
        <div class="col-xs-4 col-xs-offset-1">
        <select  class="form-control" name="course">
            <option>--Select Course Code--</option>
            <option value="EDU-431">EDU-431:Guidance and Counselling I</option>
            <option value="EDU-432">EDU-432:Guidance and Counselling II</option>
            <option value="EDU-411">EDU-411:Education for People with Special Needs</option>
            <option value="EDU-412">EDU-412:Teaching Practice II</option>
            <option value="EDU-413">EDU-413:Project</option>
        </select>  
         </div>
        <div class="col-xs-2">
            <input type="text" class="form-control" name="score" placeholder="Score" />
        </div>
        <div class="col-xs-1">
            <button type="button" class="btn btn-default removeButton"><i class="fa fa-minus"></i></button>
        </div>
    </div>

    <div class="form-group">
        <div class="col-xs-5 col-xs-offset-1">
            <button type="submit" class="btn btn-default">Submit</button>
        </div>
    </div>
</form>

<script>
$(document).ready(function() {
    var courseValidators = {
            row: '.col-xs-4',   // The course is placed inside a <div class="col-xs-4"> element
            validators: {
                notEmpty: {
                    message: 'The course title is required'
                }
            }
        },
        scoreValidators = {
            row: '.col-xs-2',
            validators: {
                notEmpty: {
                    message: 'The course score is required'
                },
                numeric: {
                    message: 'The score must be a numeric number'
                }
            }
        },
        courseIndex = 0;

    $('#courseForm')
        .formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                'course[0].course': courseValidators,
                'course[0].score': scoreValidators
            }
        })

        // Add button click handler
        .on('click', '.addButton', function() {
            courseIndex++;
            var $template = $('#courseTemplate'),
                $clone    = $template
                                .clone()
                                .removeClass('hide')
                                .removeAttr('id')
                                .attr('data-course-index', courseIndex)
                                .insertBefore($template);

            // Update the name attributes
            $clone
                .find('[name="course"]').attr('name', 'course[' + courseIndex + '].course').end()
                .find('[name="score"]').attr('name', 'course[' + courseIndex + '].score').end();

            // Add new fields
            // Note that we also pass the validator rules for new field as the third parameter
            $('#courseForm')
                .formValidation('addField', 'course[' + courseIndex + '].course', courseValidators)
                .formValidation('addField', 'course[' + courseIndex + '].score', scoreValidators);
        })

        // Remove button click handler
        .on('click', '.removeButton', function() {
            var $row  = $(this).parents('.form-group'),
                index = $row.attr('data-course-index');

            // Remove fields
            $('#courseForm')
                .formValidation('removeField', $row.find('[name="course[' + index + '].course"]'))
                .formValidation('removeField', $row.find('[name="course[' + index + '].score"]'));

            // Remove element containing the fields
            $row.remove();
        });
});
</script>
            </div>
        </div>
    </div>
</body>
</html>