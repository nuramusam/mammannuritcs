<html>
 <head>
  <title>Dynamic Rows</title>
  <script src="js/jquery-1.11.0.min.js"></script>   
 <script src="js/script.js"></script>   
 <script type="text/javascript">

 </script>
    <style type="text/css" media="screen">

        table.border1{
        border-collapse:collapse;
        border:1px solid #FF0000;
        }

        table.border1 td{
        border:1px solid #FF0000;
        }
        .border1 input {border-style:none; background: transparent;}

  </style>

 </head>
 <body onload="addNewRow1();">
    <form method="POST">
    <button type="button" name="save" onclick="actsave('save');">Simpan</button></td>   
    <table class="border1" id="border1">
        <tr>
            <td>Barcode</td>
            <td>Kode</td>
            <td>Nama</td>
        </tr>
    </table>
    </form>


 </body>
</html>