<html>
<head>
<script language="javascript">
function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
	
 var course=document.getElementById("course_row"+no);
 var quantity=document.getElementById("quantity_row"+no);
	
 var course_data=course.innerHTML;
 var quantity_data=quantity.innerHTML;
	
  course.innerHTML="<input type='text' name='course_row"+no+"' id='course_text"+no+"' value='"+course_data+"' />";
 quantity.innerHTML="<input type='text' name='quantity_row"+no+"' id='quantity_text"+no+"' value='"+quantity_data+"' />";
}

function save_row(no)
{
 var course_val=document.getElementById("course_text"+no).value;
 var quantity_val=document.getElementById("quantity_text"+no).value;

 document.getElementById("course_row"+no).innerHTML=course_val;
 document.getElementById("quantity_row"+no).innerHTML=quantity_val;

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
}

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
}

function add_row()
{
 var new_course=document.getElementById("new_course").value;
 var new_quantity=document.getElementById("new_quantity").value;
	
 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='course_row"+table_len+"' name='course_row"+table_len+"'>"+new_course+"</td><td id='quantity_row"+table_len+"' name='quantity_row"+table_len+"'>"+new_quantity+"</td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='edit' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'> <input type='button' value='Delete' class='delete' onclick='delete_row("+table_len+")'></td></tr>";

 document.getElementById("new_course").value="";
 document.getElementById("new_quantity").value="";
}
</script>
<title></title>
</head>
<body>
<div id="wrapper">
<table align='center' cellspacing=2 cellpadding=5 id="data_table" border=1>
<tr>
<th>PRODUCT</th>
<th>QUANTITY</th>
</tr>

<tr>
<td><select name="course_row1" id="new_course">
                     <option>--Select Product--</option>
                    <option value="Day old Chicks" >Day old Chicks</option>
                    <option value="Eggs" >Eggs</option>
                    <option value="Poultry Feed Mash" >Poultry Feed Mash</option>
                    <option value="Feed Mill Service" >Feed Mill Service</option>
                    <option value="Chickens" >Chickens</option>
                    <option value="Poultry Dropings" >Poultry Dropings</option>
                    </select></td>
<td><input type="text" name="quantity_row1" id="new_quantity" ></td>
<td><input type="button" class="add" onClick="add_row();" value="Add Row"></td>
</tr>

</table>
</div>

</body>
</html>