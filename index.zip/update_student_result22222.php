<?php require_once('Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE student SET admission_no=%s, full_name=%s, study_state=%s, study_center=%s, course=%s, semester=%s, `level`=%s, course_row1=%s, score_row1=%s, course_row2=%s, score_row2=%s, course_row3=%s, score_row3=%s, course_row4=%s, score_row4=%s, course_row5=%s, score_row5=%s, course_row6=%s, score_row6=%s, course_row7=%s, score_row7=%s, course_row8=%s, score_row8=%s, course_row9=%s, score_row9=%s, course_row10=%s, score_row10=%s, course_row11=%s, score_row11=%s, course_row12=%s, score_row12=%s, course_row13=%s, score_row13=%s, course_row14=%s, score_row14=%s, course_row15=%s, score_row15=%s, course_row16=%s, score_row16=%s, course_row17=%s, score_row17=%s, course_row18=%s, score_row18=%s, course_row19=%s, score_row19=%s, course_row20=%s, score_row20=%s, course_row21=%s, score_row21=%s, course_row22=%s, score_row22=%s, course_row23=%s, score_row23=%s, course_row24=%s, score_row24=%s, course_row25=%s, score_row25=%s, course_row26=%s, score_row26=%s, course_row27=%s, score_row27=%s, course_row28=%s, score_row28=%s, course_row29=%s, score_row29=%s, course_row30=%s, score_row30=%s WHERE id=%s",
                       GetSQLValueString($_POST['admission_no'], "text"),
                       GetSQLValueString($_POST['full_name'], "text"),
                       GetSQLValueString($_POST['study_state'], "text"),
                       GetSQLValueString($_POST['study_center'], "text"),
                       GetSQLValueString($_POST['course'], "text"),
                       GetSQLValueString($_POST['semester'], "text"),
                       GetSQLValueString($_POST['level'], "text"),
                       GetSQLValueString($_POST['course_row1'], "text"),
                       GetSQLValueString($_POST['score_row1'], "int"),
                       GetSQLValueString($_POST['course_row2'], "text"),
                       GetSQLValueString($_POST['score_row2'], "int"),
                       GetSQLValueString($_POST['course_row3'], "text"),
                       GetSQLValueString($_POST['score_row3'], "int"),
                       GetSQLValueString($_POST['course_row4'], "text"),
                       GetSQLValueString($_POST['score_row4'], "int"),
                       GetSQLValueString($_POST['course_row5'], "text"),
                       GetSQLValueString($_POST['score_row5'], "int"),
                       GetSQLValueString($_POST['course_row6'], "text"),
                       GetSQLValueString($_POST['score_row6'], "int"),
                       GetSQLValueString($_POST['course_row7'], "text"),
                       GetSQLValueString($_POST['score_row7'], "int"),
                       GetSQLValueString($_POST['course_row8'], "text"),
                       GetSQLValueString($_POST['score_row8'], "int"),
                       GetSQLValueString($_POST['course_row9'], "text"),
                       GetSQLValueString($_POST['score_row9'], "int"),
                       GetSQLValueString($_POST['course_row10'], "text"),
                       GetSQLValueString($_POST['score_row10'], "int"),
                       GetSQLValueString($_POST['course_row11'], "text"),
                       GetSQLValueString($_POST['score_row11'], "int"),
                       GetSQLValueString($_POST['course_row12'], "text"),
                       GetSQLValueString($_POST['score_row12'], "int"),
                       GetSQLValueString($_POST['course_row13'], "text"),
                       GetSQLValueString($_POST['score_row13'], "int"),
                       GetSQLValueString($_POST['course_row14'], "text"),
                       GetSQLValueString($_POST['score_row14'], "int"),
                       GetSQLValueString($_POST['course_row15'], "text"),
                       GetSQLValueString($_POST['score_row15'], "int"),
                       GetSQLValueString($_POST['course_row16'], "text"),
                       GetSQLValueString($_POST['score_row16'], "int"),
                       GetSQLValueString($_POST['course_row17'], "text"),
                       GetSQLValueString($_POST['score_row17'], "int"),
                       GetSQLValueString($_POST['course_row18'], "text"),
                       GetSQLValueString($_POST['score_row18'], "int"),
                       GetSQLValueString($_POST['course_row19'], "text"),
                       GetSQLValueString($_POST['score_row19'], "int"),
                       GetSQLValueString($_POST['course_row20'], "text"),
                       GetSQLValueString($_POST['score_row20'], "int"),
					   GetSQLValueString($_POST['course_row21'], "text"),
                       GetSQLValueString($_POST['score_row21'], "int"),
					   GetSQLValueString($_POST['course_row22'], "text"),
                       GetSQLValueString($_POST['score_row22'], "int"),
					   GetSQLValueString($_POST['course_row23'], "text"),
                       GetSQLValueString($_POST['score_row23'], "int"),
					   GetSQLValueString($_POST['course_row24'], "text"),
                       GetSQLValueString($_POST['score_row24'], "int"),
					   GetSQLValueString($_POST['course_row25'], "text"),
                       GetSQLValueString($_POST['score_row25'], "int"),
					   GetSQLValueString($_POST['course_row26'], "text"),
                       GetSQLValueString($_POST['score_row26'], "int"),
					   GetSQLValueString($_POST['course_row27'], "text"),
                       GetSQLValueString($_POST['score_row27'], "int"),
					   GetSQLValueString($_POST['course_row28'], "text"),
                       GetSQLValueString($_POST['score_row28'], "int"),
					   GetSQLValueString($_POST['course_row29'], "text"),
                       GetSQLValueString($_POST['score_row29'], "int"),
					   GetSQLValueString($_POST['course_row30'], "text"),
                       GetSQLValueString($_POST['score_row30'], "int"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_nti_ca, $nti_ca);
  $Result1 = mysql_query($updateSQL, $nti_ca) or die(mysql_error());

  $updateGoTo = "student_successfully_update.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_update_studentRecord = "-1";
if (isset($_GET['admission_no'])) {
  $colname_update_studentRecord = $_GET['admission_no'];
}
mysql_select_db($database_nti_ca, $nti_ca);
$query_update_studentRecord = sprintf("SELECT * FROM student WHERE admission_no = %s", GetSQLValueString($colname_update_studentRecord, "text"));
$update_studentRecord = mysql_query($query_update_studentRecord, $nti_ca) or die(mysql_error());
$row_update_studentRecord = mysql_fetch_assoc($update_studentRecord);
$totalRows_update_studentRecord = mysql_num_rows($update_studentRecord);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script language="javascript">
function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
	
 var course=document.getElementById("course_row"+no);
 var score=document.getElementById("score_row"+no);
	
 var course_data=course.innerHTML;
 var score_data=score.innerHTML;
	
  course.innerHTML="<input type='text' name='course_row"+no+"' id='course_row"+no+"' value='"+course_data+"' />";
 score.innerHTML="<input type='text' name='score_row"+no+"' id='score_row"+no+"' value='"+score_data+"' />";
}


function add_row()
{
 var new_course=document.getElementById("new_course").value;
 var new_score=document.getElementById("new_score").value;
	
 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='course_row"+table_len+"' name='course_row"+table_len+"'>"+new_course+"</td><td id='score_row"+table_len+"' name='score_row"+table_len+"'>"+new_score+"</td><td><input type='button' id='edit_button"+table_len+"' value='Activate' class='Text_field_style' onclick='edit_row("+table_len+")'> <input type='hidden' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'></td></tr>";

 document.getElementById("new_course").value="";
 document.getElementById("new_score").value="";
}
</script>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="index.html" class="current_page_item">HOME</a></li>
        <li><a href="tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap">
		    <p align="justify"><a href="admin_master_page.php">BACK TO MASTER PAGE</a>		    </p>
		    <form action="<?php echo $editFormAction; ?>" method="post" id="form1">
		      <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $row_update_studentRecord['id']; ?>" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Admission No:</td>
                  <td>&nbsp;</td>
                  <td><input name="admission_no" type="text" value="<?php echo htmlentities($row_update_studentRecord['admission_no'], ENT_COMPAT, 'utf-8'); ?>" size="15" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Student Name:</td>
                  <td>&nbsp;</td>
                  <td><input name="full_name" type="text" value="<?php echo htmlentities($row_update_studentRecord['full_name'], ENT_COMPAT, 'utf-8'); ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study State:</td>
                  <td>&nbsp;</td>
                  <td><input name="study_state" type="text" value="<?php echo htmlentities($row_update_studentRecord['study_state'], ENT_COMPAT, 'utf-8'); ?>" size="15" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study Center:</td>
                  <td>&nbsp;</td>
                  <td><input name="study_center" type="text" value="<?php echo htmlentities($row_update_studentRecord['study_center'], ENT_COMPAT, 'utf-8'); ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Course:</td>
                  <td>&nbsp;</td>
                  <td><input name="course" type="text" value="<?php echo htmlentities($row_update_studentRecord['course'], ENT_COMPAT, 'utf-8'); ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Semester:</td>
                  <td>&nbsp;</td>
                  <td><input name="semester" type="text" value="<?php echo htmlentities($row_update_studentRecord['semester'], ENT_COMPAT, 'utf-8'); ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Level:</td>
                  <td>&nbsp;</td>
                  <td><input name="level" type="text" value="<?php echo htmlentities($row_update_studentRecord['level'], ENT_COMPAT, 'utf-8'); ?>" size="10" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="right"><div id="wrapper">
<table align='center' id="data_table">
<tr>
<th bgcolor="#CCCCCC"><strong>COURSE CODE AND TITLE</strong></th>
<th bgcolor="#CCCCCC"><strong>SCORE</strong></th>
</tr>

<tr>
  <td><label for="course_row1"></label>
    <select name="course_row1" id="course_row1">
    <option>--SELECT COURSE--</option>
<option value="EDU-101">EDU-101: Historical Foundation of Education</option>
                     <option value="EDU-102">EDU-102: Sociological Foundation of Education</option>
                     <option value="EDU-111">EDU-111: Educational Psychology: Child Development I</option>
                     <option value="EDU-112">EDU-112: Educational Psychology: Child Development II</option>
                     <option value="EDU-113">EDU-113: Educational Psychology: Child Development III</option>
                     <option value="EDU-123">EDU-123: General Principle and Method I</option>
                     <option value="EDU-124">EDU-124: General Principle and Method II</option>
                     <option value="EDU-125">EDU-125: General Principles & Methodology of Teaching III</option>
                     <option value="GSE-101">GSE-101: Oracy Skills</option>
                     <option value="GSE-102">GSE-102: English Language Usage</option>
                     <option value="GSE-103">GSE-103: Advanced Reading Skills</option>
                     <option value="GSE-104">GSE-104: Advanced Writing Skills</option>
                     <option value="GSE-105">GSE-105: Citizenship Educatio</option>
                     <option value="GSE-106">GSE-106: Political Economy</option>
                     <option value="GSE-111">GSE-111: Introduction to Computer Studies</option>
                     <option value="PES-111">PES-111: His. & Cultural Background of the Immediate Env.</option>
                     <option value="PES-112">PES-112: Drawing, Cultural and Creative Arts</option>
                     <option value="PES-121">PES-121: Primary Science Curriculum and Methods</option>
                     <option value="PES-141">PES-141: Number and Operations I</option>
                     <option value="PES-142">PES-142: Number and Operations II</option>
                     <option value="CRS-101">CRS-101: Introduction to the Study of Religion</option>
                     <option value="CRS-102">CRS-102: Critical Introduction of the Bible</option>
                     <option value="CRS-111">CRS-111: Biblical World of the Old Testament</option>
                     <option value="CRS-112">CRS-112: Intro. to the Theology of The Old Testament</option>
    </select></td>
  <td><label for="score_row1"></label>
    <input name="score_row1" type="text" id="score_row1" size="10" /></td>
  <td>&nbsp;</td>
</tr>
<tr>
<td><select name="course_row1" id="new_course">
  <option>--SELECT COURSE--</option>
<option value="EDU-101">EDU-101: Historical Foundation of Education</option>
                     <option value="EDU-102">EDU-102: Sociological Foundation of Education</option>
                     <option value="EDU-111">EDU-111: Educational Psychology: Child Development I</option>
                     <option value="EDU-112">EDU-112: Educational Psychology: Child Development II</option>
                     <option value="EDU-113">EDU-113: Educational Psychology: Child Development III</option>
                     <option value="EDU-123">EDU-123: General Principle and Method I</option>
                     <option value="EDU-124">EDU-124: General Principle and Method II</option>
                     <option value="EDU-125">EDU-125: General Principles & Methodology of Teaching III</option>
                     <option value="GSE-101">GSE-101: Oracy Skills</option>
                     <option value="GSE-102">GSE-102: English Language Usage</option>
                     <option value="GSE-103">GSE-103: Advanced Reading Skills</option>
                     <option value="GSE-104">GSE-104: Advanced Writing Skills</option>
                     <option value="GSE-105">GSE-105: Citizenship Educatio</option>
                     <option value="GSE-106">GSE-106: Political Economy</option>
                     <option value="GSE-111">GSE-111: Introduction to Computer Studies</option>
                     <option value="PES-111">PES-111: His. & Cultural Background of the Immediate Env.</option>
                     <option value="PES-112">PES-112: Drawing, Cultural and Creative Arts</option>
                     <option value="PES-121">PES-121: Primary Science Curriculum and Methods</option>
                     <option value="PES-141">PES-141: Number and Operations I</option>
                     <option value="PES-142">PES-142: Number and Operations II</option>
                     <option value="CRS-101">CRS-101: Introduction to the Study of Religion</option>
                     <option value="CRS-102">CRS-102: Critical Introduction of the Bible</option>
                     <option value="CRS-111">CRS-111: Biblical World of the Old Testament</option>
                     <option value="CRS-112">CRS-112: Intro. to the Theology of The Old Testament</option>
</select></td>
<td><input name="score_row1" type="text" id="new_score" ></td>
<td><input type="button" class="Text_field_style" onClick="add_row();" value="Add Course"></td>
</tr>

</table>
</div></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input type="submit" class="Text_field_style" value="Update Result" /></td>
                </tr>
              </table>
              <input type="hidden" name="MM_update" value="form1" />
              <input type="hidden" name="id" value="<?php echo $row_update_studentRecord['id']; ?>" />
          </form>
            <p>&nbsp;</p>
            <h1 align="justify"><strong><font color="#FFF">Discover</font></strong></h1>
		    <p align="justify">This form. <a href="#">Read More..</a></p></div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
<?php
mysql_free_result($update_studentRecord);
?>
