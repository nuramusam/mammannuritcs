<?php require_once('Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO student (id, admission_no, full_name, study_state, study_center, course, semester, `level`, course_row1, score_row1, course_row2, score_row2, course_row3, score_row3, course_row4, score_row4, course_row5, score_row5, course_row6, score_row6, course_row7, score_row7, course_row8, score_row8, course_row9, score_row9, course_row10, score_row10, course_row11, score_row11, course_row12, score_row12, course_row13, score_row13, course_row14, score_row14, course_row15, score_row15, course_row16, score_row16, course_row17, score_row17, course_row18, score_row18, course_row19, score_row19, course_row20, score_row20) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['id'], "int"),
                       GetSQLValueString($_POST['admission_no'], "text"),
                       GetSQLValueString($_POST['full_name'], "text"),
                       GetSQLValueString($_POST['study_state'], "text"),
                       GetSQLValueString($_POST['study_center'], "text"),
                       GetSQLValueString($_POST['course'], "text"),
                       GetSQLValueString($_POST['semester'], "text"),
                       GetSQLValueString($_POST['level'], "text"),
                       GetSQLValueString($_POST['course_row1'], "text"),
                       GetSQLValueString($_POST['score_row1'], "int"),
                       GetSQLValueString($_POST['course_row2'], "text"),
                       GetSQLValueString($_POST['score_row2'], "int"),
                       GetSQLValueString($_POST['course_row3'], "text"),
                       GetSQLValueString($_POST['score_row3'], "int"),
                       GetSQLValueString($_POST['course_row4'], "text"),
                       GetSQLValueString($_POST['score_row4'], "int"),
                       GetSQLValueString($_POST['course_row5'], "text"),
                       GetSQLValueString($_POST['score_row5'], "int"),
                       GetSQLValueString($_POST['course_row6'], "text"),
                       GetSQLValueString($_POST['score_row6'], "int"),
                       GetSQLValueString($_POST['course_row7'], "text"),
                       GetSQLValueString($_POST['score_row7'], "int"),
                       GetSQLValueString($_POST['course_row8'], "text"),
                       GetSQLValueString($_POST['score_row8'], "int"),
                       GetSQLValueString($_POST['course_row9'], "text"),
                       GetSQLValueString($_POST['score_row9'], "int"),
                       GetSQLValueString($_POST['course_row10'], "text"),
                       GetSQLValueString($_POST['score_row10'], "int"),
                       GetSQLValueString($_POST['course_row11'], "text"),
                       GetSQLValueString($_POST['score_row11'], "int"),
                       GetSQLValueString($_POST['course_row12'], "text"),
                       GetSQLValueString($_POST['score_row12'], "int"),
                       GetSQLValueString($_POST['course_row13'], "text"),
                       GetSQLValueString($_POST['score_row13'], "int"),
                       GetSQLValueString($_POST['course_row14'], "text"),
                       GetSQLValueString($_POST['score_row14'], "int"),
                       GetSQLValueString($_POST['course_row15'], "text"),
                       GetSQLValueString($_POST['score_row15'], "int"),
                       GetSQLValueString($_POST['course_row16'], "text"),
                       GetSQLValueString($_POST['score_row16'], "int"),
                       GetSQLValueString($_POST['course_row17'], "text"),
                       GetSQLValueString($_POST['score_row17'], "int"),
                       GetSQLValueString($_POST['course_row18'], "text"),
                       GetSQLValueString($_POST['score_row18'], "int"),
                       GetSQLValueString($_POST['course_row19'], "text"),
                       GetSQLValueString($_POST['score_row19'], "int"),
                       GetSQLValueString($_POST['course_row20'], "text"),
                       GetSQLValueString($_POST['score_row20'], "int"));
  mysql_select_db($database_nti_ca, $nti_ca);
  $Result1 = mysql_query($insertSQL, $nti_ca) or die(mysql_error());

  $insertGoTo = "student_preview.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_nti_ca, $nti_ca);
$query_remark = "SELECT * FROM student";
$remark = mysql_query($query_remark, $nti_ca) or die(mysql_error());
$row_remark = mysql_fetch_assoc($remark);
$totalRows_remark = mysql_num_rows($remark);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Adding Student National Teachers' Institute, Kaduna</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript">
 //<![CDATA[ 
 // array of possible countries in the same order as they appear in the country selection list 
 var stateLists = new Array(4) 
 stateLists["empty"] = ["Select a Study Center"]; 
 stateLists["Kaduna"] = ["KTC Kawo Kaduna", "GSS Darlet Barracks", "SMC Kaduna"]; 
 stateLists["Kano"] = ["GSS Kurmin Mashi", "GSS Sabon Tasha", "GSS kufena Zaria"]; 
 stateLists["Katsina"] = ["GSS Kakuri", "SSS Ikara", "GC Zonkuwa"]; 
 stateLists["Niger"]= ["SSS Birnin Gwari", "GC Saminaka", "WTC Kaduna", "GGSS Doka"]; 
 /* StateChange() is called from the onchange event of a select element. 
 * param selectObj - the select object which fired the on change event. 
 */ 
 function countryChange(selectObj) { 
 // get the index of the selected option 
 var idx = selectObj.selectedIndex; 
 // get the value of the selected option 
 var which = selectObj.options[idx].value; 
 // use the selected option value to retrieve the list of items from the stateLists array 
 cList = stateLists[which]; 
 // get the country select element via its known id 
 var cSelect = document.getElementById("country"); 
 // remove the current options from the country select 
 var len=cSelect.options.length; 
 while (cSelect.options.length > 0) { 
 cSelect.remove(0); 
 } 
 var newOption; 
 // create new options 
 for (var i=0; i<cList.length; i++) { 
 newOption = document.createElement("option"); 
 newOption.value = cList[i];  // assumes option string and value are the same 
 newOption.text=cList[i]; 
 // add the new option 
 try { 
 cSelect.add(newOption);  // this will fail in DOM browsers but is needed for IE 
 } 
 catch (e) { 
 cSelect.appendChild(newOption); 
 } 
 } 
 } 
//]]>
</script>
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="index.html" class="current_page_item">HOME</a></li>
        <li><a href="tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title"><strong><font color="#FFF">National Teachers' Institute Score Entering Form...</font></strong>		  </h1>
		  <div class="current_page_item" id="calendar_wrap">
		    <form action="<?php echo $editFormAction; ?>" method="post" id="form1">
              <table>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td><input type="hidden" name="id" id="id" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Registration No:</td>
                  <td><input type="text" name="admission_no" value="" size="32" style="text-transform:uppercase" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Student Full Name:</td>
                  <td><input type="text" name="full_name" value="" size="32" style="text-transform:uppercase" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study State:</td>
                  <td><select name="study_state" id="continent" onchange="countryChange(this);" style="text-transform:capitalize">
                    <option value="empty" selected="selected">Select a State</option>
    				<option value="Kaduna">KADUNA</option>
    				<option value="Kano">KANO</option>
    				<option value="Katsina">KATSINA</option>
    				<option value="Niger">NIGERINA</option>
                  </select></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study Center:</td>
                  <td><select name="study_center" id="country" style="text-transform:capitalize">
                    <option value="0">Select a Study Center</option>
                  </select></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Course of Study:</td>
                  <td><select name="course">
                    <option value="" >--Select--</option>
                    <option value="PES/SOS">PRIMARY EDUCATION STUDIES / SOCIAL STUDIES</option>
                    <option value="PES/CRS">PRIMARY EDUCATION STUDIES / CHRISTIAN RELIGIOUS STUDIES</option>
                  </select></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">NCE Level:</td>
                  <td valign="baseline"><table>
                    <tr>
                      <td><input type="radio" name="level" value="NCE 1" />
                        NCE 1</td>
                    </tr>
                    <tr>
                      <td><input type="radio" name="level" value="NCE 2" />
                        NCE 2</td>
                    </tr>
                    <tr>
                      <td><input type="radio" name="level" value="NCE 3" />
                        NCE 3</td>
                    </tr>
                    <tr>
                      <td><input type="radio" name="level" value="NCE 4" />
                        NCE 4</td>
                    </tr>
                  </table></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Semester:</td>
                  <td><select name="semester">
                    <option value="" >--Select--</option>
                    <option value="FIRST SEMESTER">FIRST SEMESTER</option>
                    <option value="SECOND SEMESTER">SECOND SEMESTER</option>
                  </select></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td><input type="submit" value="Submit" />
                  <input type="reset" name="Reset" id="button" value="Reset" /></td>
                </tr>
              </table>
              <input type="hidden" name="MM_insert" value="form1" />
            </form>
            <p>&nbsp;</p></div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
<?php
mysql_free_result($remark);
?>
