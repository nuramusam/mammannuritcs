<?PHP
include_once "config.php";
$act=filter_input(INPUT_POST,'action');
if($act=="save"){
    $datas=new crud_datas();
    $datas->savedata();
}

class crud_datas{
    function savedata(){
            $db=new database();
            $db->connection();
            foreach($_POST['BARCODE'] as $index => $barcode){
            $barcode = $_POST['BARCODE'][$index];
            $kode1 = $_POST['KODE1'][$index];
            $nama1 = $_POST['NAMA1'][$index];
            mysql_query("INSERT INTO table_details (barcode,kode,nama) VALUES ('".$barcode."','".$kode1."','".$nama1."')");
            }
    }
}
?>