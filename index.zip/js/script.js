 var baris1=1;
addNewRow1();
function addNewRow1() {
var tbl = document.getElementById("border1");
var row = tbl.insertRow(tbl.rows.length);
row.id = 't1'+baris1;

var td1 = document.createElement("td");
var td2 = document.createElement("td");
var td3 = document.createElement("td");

td1.appendChild(generateBARCODE(baris1));
td2.appendChild(generateKODE1(baris1));
td3.appendChild(generateNAMA1(baris1));

row.appendChild(td1);
row.appendChild(td2);
row.appendChild(td3);

document.getElementById('NAMA1['+baris1+']').setAttribute('onchange', 'newrow()');

document.getElementById('BARCODE['+baris1+']').focus();
baris1++;
}
function generateBARCODE(index) {
var idx = document.createElement("input");
idx.type = "text";

idx.id = "BARCODE["+index+"]";
idx.name = "BARCODE["+index+"]";

idx.size = "10";

return idx;
}
function generateKODE1(index) {
var idx = document.createElement("input");
idx.type = "text";

idx.id = "KODE1["+index+"]";
idx.name = "KODE1["+index+"]";

idx.size = "20";
return idx;
}
function generateNAMA1(index) {
var idx = document.createElement("input");
idx.type = "text";

idx.id = "NAMA1["+index+"]";
idx.name = "NAMA1["+index+"]";

idx.size = "20";
return idx;
}

function actsave(act){
    if(act){
        var action=act;
    }
    var datass= $('#border1').serialize();

    $.ajax({
       type: "POST",
       url: "php/phpclass.php",
       data: {action:action,datass:datass},
       success: function(result) {
         //ur success handler OPTIONAL
            }
    });
    return false;
}

function newrow(){
                    addNewRow1();      
}