<?php require_once('../../../Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_Recordset1 = "-1";
if (isset($_GET['admission_no'])) {
  $colname_Recordset1 = $_GET['admission_no'];
}
mysql_select_db($database_nti_ca, $nti_ca);
$query_Recordset1 = sprintf("SELECT * FROM c1firstsemesterpesirs WHERE admission_no = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $nti_ca) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="../../../images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="../../../style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="../../../index.html" class="current_page_item">HOME</a></li>
        <li><a href="../../../tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="../../../admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="../../../contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm"> 
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <a href="C1A.php"><br />
		  <font align="left" class="Text_Field">GO BACK</font>
		  </a>
		  <div class="current_page_item" id="calendar_wrap">
  <h3 align="center"><strong><font color="#FFF">CA RUSULT SHEET OF</font><font color="#FF0000"> <?php echo $row_Recordset1['full_name']; ?></font></strong></h3>
<p align="justify">&nbsp;</p>
<table width="auto" border="0" cellpadding="4">
  <tr>
    <td><strong>REG. NO: </strong></td>
    <td><?php echo $row_Recordset1['admission_no']; ?></td>
    <td colspan="2" rowspan="2">&nbsp;</td>
    <td><strong>NAME:</strong></td>
    <td><?php echo $row_Recordset1['full_name']; ?></td>
  </tr>
  <tr>
    <td><strong>STUDY STATE:</strong></td>
    <td><?php echo $row_Recordset1['study_state']; ?></td>
    <td><strong>STUDY CENTER:</strong></td>
    <td><?php echo $row_Recordset1['study_center']; ?></td>
  </tr>
  <tr>
    <td><strong>COURSE:</strong></td>
    <td><?php echo $row_Recordset1['course']; ?></td>
    <td colspan="4">&nbsp;</td>
    </tr>
  <tr>
    <td><strong>LEVEL:</strong></td>
    <td><?php echo $row_Recordset1['level']; ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><strong>SEMESTER:</strong></td>
    <td><?php echo $row_Recordset1['semester']; ?></td>
  </tr>
  <tr>
    <td colspan="6">
    <table>
    <tr valign="top">
      <td><table border="1" cellpadding="4">
    <tr>
      <td colspan="2" bgcolor="#663366" align="center"><strong>EDUCATION SUBJECTS</strong></td>
      </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row1']; ?></td>
      <td><?php echo $row_Recordset1['score_row1']; ?></td>
      </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row2']; ?></td>
      <td><?php echo $row_Recordset1['score_row2']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row3']; ?></td>
      <td><?php echo $row_Recordset1['score_row3']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row4']; ?></td>
      <td><?php echo $row_Recordset1['score_row4']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row5']; ?></td>
      <td><?php echo $row_Recordset1['score_row5']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row6']; ?></td>
      <td><?php echo $row_Recordset1['score_row6']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row7']; ?></td>
      <td><?php echo $row_Recordset1['score_row7']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row8']; ?></td>
      <td><?php echo $row_Recordset1['score_row8']; ?></td>
    </tr>
    </table></td>
      <td><table border="1" cellpadding="4">
    <tr>
      <td colspan="2" bgcolor="#663366"><strong>GSE SUBJECTS</strong></td>
      </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row9']; ?></td>
      <td><?php echo $row_Recordset1['score_row9']; ?></td>
      </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row10']; ?></td>
      <td><?php echo $row_Recordset1['score_row10']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row11']; ?></td>
      <td><?php echo $row_Recordset1['score_row11']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row12']; ?></td>
      <td><?php echo $row_Recordset1['score_row12']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row13']; ?></td>
      <td><?php echo $row_Recordset1['score_row13']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row14']; ?></td>
      <td><?php echo $row_Recordset1['score_row14']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row15']; ?></td>
      <td><?php echo $row_Recordset1['score_row15']; ?></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    </table></td>
      <td><table border="1" cellpadding="4">
    <tr>
      <td colspan="2" bgcolor="#663366"><strong>GSE SUBJECTS</strong></td>
      </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row16']; ?></td>
      <td><?php echo $row_Recordset1['score_row16']; ?></td>
      </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row17']; ?></td>
      <td><?php echo $row_Recordset1['score_row17']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row18']; ?></td>
      <td><?php echo $row_Recordset1['score_row18']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row12']; ?></td>
      <td><?php echo $row_Recordset1['score_row12']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row13']; ?></td>
      <td><?php echo $row_Recordset1['score_row13']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row14']; ?></td>
      <td><?php echo $row_Recordset1['score_row14']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row15']; ?></td>
      <td><?php echo $row_Recordset1['score_row15']; ?></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    </table></td>
      <td><table border="1" cellpadding="4">
    <tr>
      <td colspan="2" bgcolor="#663366"><strong>GSE SUBJECTS</strong></td>
      </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row9']; ?></td>
      <td><?php echo $row_Recordset1['score_row9']; ?></td>
      </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row10']; ?></td>
      <td><?php echo $row_Recordset1['score_row10']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row11']; ?></td>
      <td><?php echo $row_Recordset1['score_row11']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row12']; ?></td>
      <td><?php echo $row_Recordset1['score_row12']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row13']; ?></td>
      <td><?php echo $row_Recordset1['score_row13']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row14']; ?></td>
      <td><?php echo $row_Recordset1['score_row14']; ?></td>
    </tr>
    <tr>
      <td><?php echo $row_Recordset1['course_row15']; ?></td>
      <td><?php echo $row_Recordset1['score_row15']; ?></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    </table></td>
      </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    </table>
    </td>
    </tr>
</table>
<h1>&nbsp;</h1>
<p align="justify">&nbsp;</p>
        </div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
