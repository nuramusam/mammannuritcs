<?php require_once('../../../Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO c1firstsemesterpesirs (id, admission_no, full_name, study_state, study_center, course, semester, `level`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['id'], "int"),
                       GetSQLValueString($_POST['admission_no'], "text"),
                       GetSQLValueString($_POST['full_name'], "text"),
                       GetSQLValueString($_POST['study_state'], "text"),
                       GetSQLValueString($_POST['study_center'], "text"),
                       GetSQLValueString($_POST['course'], "text"),
                       GetSQLValueString($_POST['semester'], "text"),
                       GetSQLValueString($_POST['level'], "text"));

  mysql_select_db($database_nti_ca, $nti_ca);
  $Result1 = mysql_query($insertSQL, $nti_ca) or die(mysql_error());

  $insertGoTo = "C1ASuccess.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="../../../images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="../../../style.css" rel="stylesheet" type="text/css" media="screen" />
<script src="../../../SpryAssets/SpryAccordion.js" type="text/javascript"></script>
<link href="../../../SpryAssets/SpryAccordion.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
 //<![CDATA[ 
 // array of possible countries in the same order as they appear in the country selection list 
 var stateLists = new Array(4) 
 stateLists["empty"] = ["Select a Study Center"]; 
 stateLists["KADUNA"] = ["KADUNA TEACHERS' COLLEGE, KADUNA", "GOVT SECONDARY SCHOOL, DALET BARRACKS, KADUNA", "SARDAUNA MEMORIAL COLLEGE, KADUNA"]; 
 stateLists["KANO"] = ["GSS Kurmin Mashi", "GSS Sabon Tasha", "GSS kufena Zaria"]; 
 stateLists["KATSINA"] = ["GSS Kakuri", "SSS Ikara", "GC Zonkuwa"]; 
 stateLists["NIGER"]= ["SSS Birnin Gwari", "GC Saminaka", "WTC Kaduna", "GGSS Doka"]; 
 /* StateChange() is called from the onchange event of a select element. 
 * param selectObj - the select object which fired the on change event. 
 */ 
 function countryChange(selectObj) { 
 // get the index of the selected option 
 var idx = selectObj.selectedIndex; 
 // get the value of the selected option 
 var which = selectObj.options[idx].value; 
 // use the selected option value to retrieve the list of items from the stateLists array 
 cList = stateLists[which]; 
 // get the country select element via its known id 
 var cSelect = document.getElementById("country"); 
 // remove the current options from the country select 
 var len=cSelect.options.length; 
 while (cSelect.options.length > 0) { 
 cSelect.remove(0); 
 } 
 var newOption; 
 // create new options 
 for (var i=0; i<cList.length; i++) { 
 newOption = document.createElement("option"); 
 newOption.value = cList[i];  // assumes option string and value are the same 
 newOption.text=cList[i]; 
 // add the new option 
 try { 
 cSelect.add(newOption);  // this will fail in DOM browsers but is needed for IE 
 } 
 catch (e) { 
 cSelect.appendChild(newOption); 
 } 
 } 
 } 
//]]>
</script>
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="../../../index.html" class="current_page_item">HOME</a></li>
        <li><a href="../../../tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="../../../admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="../../../contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Primary Education Studies / Islamic Religious Studies Cycle I First Semester Page</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap">
		    <p align="justify"><a href="../../pesirs.php" class="Text_Field">CLICK TO GO BACK</a></p>
<div id="Accordion1" class="Accordion" tabindex="0">
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">ADD NEW STUDENT</div>
    <div class="AccordionPanelContent">
      <form action="<?php echo $editFormAction; ?>" method="post" id="form1"><table>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input type="hidden" name="id" id="id" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Registration No:</td>
                  <td>&nbsp;</td>
                  <td><input type="text" name="admission_no" value="" size="32" style="text-transform:uppercase" placeholder="NTI/NCE/2017/001" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Student Full Name:</td>
                  <td>&nbsp;</td>
                  <td><input type="text" name="full_name" value="" size="32"  placeholder="MUHAMMAD JOHN IFEANYI"style="text-transform:uppercase" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study State:</td>
                  <td>&nbsp;</td>
                  <td><select name="study_state" id="continent" onchange="countryChange(this);" style="text-transform:capitalize">
                    <option value="empty" selected="selected">Select a State</option>
    				<option value="KADUNA">KADUNA</option>
    				<option value="KANO">KANO</option>
    				<option value="KATSINA">KATSINA</option>
    				<option value="NIGER">NIGER</option>
                  </select></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study Center:</td>
                  <td>&nbsp;</td>
                  <td><select name="study_center" id="country" style="text-transform:capitalize">
                    <option value="0">Select a Study Center</option>
                  </select></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Course of Study:</td>
                  <td>&nbsp;</td>
                  <td><select name="course">
                    <option value="PES/IRS" selected="selected">PRIMARY EDUCATION STUDIES / ISLAMIC RELIGIOUS STUDIES</option>
                  </select></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">NCE Level:</td>
                  <td valign="baseline">&nbsp;</td>
                  <td valign="baseline"><table>
                    <tr>
                      <td><input name="level" type="radio" value="NCE 1" checked="checked" />
                        NCE 1</td>
                    </tr>
                  </table></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Semester:</td>
                  <td>&nbsp;</td>
                  <td><select name="semester">
                    <option value="" >--Select--</option>
                    <option value="FIRST SEMESTER" selected="selected">FIRST SEMESTER</option>
</select></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input type="submit" value="Submit" />
                  <input type="reset" name="Reset" id="button" value="Reset" /></td>
                </tr>
              </table>
        <p>
          <input type="hidden" name="MM_insert" value="form1" />
        </p>
      </form>
    </div>
  </div>
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">UPDATE STUDENT RECORD</div>
    <div class="AccordionPanelContent">
      <p>&nbsp;</p>
      <table width="500" border="0" align="center" cellpadding="2">
                    <tr>
                      <td align="right" class="Black_Color_Text">ADD STUDENT RESULT</td>
                      <td><form action="update_student_result.php" method="get" enctype="multipart/form-data" id="admission_no">
                        <input name="admission_no" type="text" id="admission_no" />
                        <input name="Update" type="submit" id="Update" value="Submit" />
                      </form></td>
                    </tr>
                    <tr>
                      <td width="138" align="right" class="Black_Color_Text">SEARCH STUDENT RESULT</td>
                      <td width="346"><form action="C1ASearchStudent.php" method="get" enctype="multipart/form-data" name="id" target="_blank" id="admission_no">
                        <label for=""></label>
                        <input name="admission_no" type="text" id="admission_no" />
                        <input name="search" type="submit" id="serch" value="Submit" />
                      </form></td>
                    </tr>
                </table>
      <p>&nbsp; </p>
    </div>
  </div>
</div>
<p align="justify">&nbsp;</p>
<p align="justify">&nbsp;</p>
          </div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
<script type="text/javascript">
var Accordion1 = new Spry.Widget.Accordion("Accordion1");
    </script>
</body>
</html>
