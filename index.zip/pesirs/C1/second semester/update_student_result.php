<?php require_once('../../../Connections/nti_ca.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE c1secondsemesterpesirs SET admission_no=%s, full_name=%s, study_state=%s, study_center=%s, course=%s, semester=%s, `level`=%s, course_row1=%s, score_row1=%s, course_row2=%s, score_row2=%s, course_row3=%s, score_row3=%s, course_row4=%s, score_row4=%s, course_row5=%s, score_row5=%s, course_row6=%s, score_row6=%s, course_row7=%s, score_row7=%s, course_row8=%s, score_row8=%s, course_row9=%s, score_row9=%s, course_row10=%s, score_row10=%s, course_row11=%s, score_row11=%s, course_row12=%s, score_row12=%s, course_row13=%s, score_row13=%s, course_row14=%s, score_row14=%s, course_row15=%s, score_row15=%s, course_row16=%s, score_row16=%s, course_row17=%s, score_row17=%s, course_row18=%s, score_row18=%s, course_row19=%s, score_row19=%s, course_row20=%s, score_row20=%s, course_row21=%s, score_row21=%s, course_row22=%s, score_row22=%s, course_row23=%s, score_row23=%s, course_row24=%s, score_row24=%s WHERE id=%s",
                       GetSQLValueString($_POST['admission_no'], "text"),
                       GetSQLValueString($_POST['full_name'], "text"),
                       GetSQLValueString($_POST['study_state'], "text"),
                       GetSQLValueString($_POST['study_center'], "text"),
                       GetSQLValueString($_POST['course'], "text"),
                       GetSQLValueString($_POST['semester'], "text"),
                       GetSQLValueString($_POST['level'], "text"),
                       GetSQLValueString($_POST['course_row1'], "text"),
                       GetSQLValueString($_POST['score_row1'], "int"),
                       GetSQLValueString($_POST['course_row2'], "text"),
                       GetSQLValueString($_POST['score_row2'], "int"),
                       GetSQLValueString($_POST['course_row3'], "text"),
                       GetSQLValueString($_POST['score_row3'], "int"),
                       GetSQLValueString($_POST['course_row4'], "text"),
                       GetSQLValueString($_POST['score_row4'], "int"),
                       GetSQLValueString($_POST['course_row5'], "text"),
                       GetSQLValueString($_POST['score_row5'], "int"),
                       GetSQLValueString($_POST['course_row6'], "text"),
                       GetSQLValueString($_POST['score_row6'], "int"),
                       GetSQLValueString($_POST['course_row7'], "text"),
                       GetSQLValueString($_POST['score_row7'], "int"),
                       GetSQLValueString($_POST['course_row8'], "text"),
                       GetSQLValueString($_POST['score_row8'], "int"),
                       GetSQLValueString($_POST['course_row9'], "text"),
                       GetSQLValueString($_POST['score_row9'], "int"),
                       GetSQLValueString($_POST['course_row10'], "text"),
                       GetSQLValueString($_POST['score_row10'], "int"),
                       GetSQLValueString($_POST['course_row11'], "text"),
                       GetSQLValueString($_POST['score_row11'], "int"),
                       GetSQLValueString($_POST['course_row12'], "text"),
                       GetSQLValueString($_POST['score_row12'], "int"),
                       GetSQLValueString($_POST['course_row13'], "text"),
                       GetSQLValueString($_POST['score_row13'], "int"),
                       GetSQLValueString($_POST['course_row14'], "text"),
                       GetSQLValueString($_POST['score_row14'], "int"),
                       GetSQLValueString($_POST['course_row15'], "text"),
                       GetSQLValueString($_POST['score_row15'], "int"),
                       GetSQLValueString($_POST['course_row16'], "text"),
                       GetSQLValueString($_POST['score_row16'], "int"),
                       GetSQLValueString($_POST['course_row17'], "text"),
                       GetSQLValueString($_POST['score_row17'], "int"),
                       GetSQLValueString($_POST['course_row18'], "text"),
                       GetSQLValueString($_POST['score_row18'], "int"),
                       GetSQLValueString($_POST['course_row19'], "text"),
                       GetSQLValueString($_POST['score_row19'], "int"),
                       GetSQLValueString($_POST['course_row20'], "text"),
                       GetSQLValueString($_POST['score_row20'], "int"),
                       GetSQLValueString($_POST['course_row21'], "text"),
                       GetSQLValueString($_POST['score_row21'], "int"),
                       GetSQLValueString($_POST['course_row22'], "text"),
                       GetSQLValueString($_POST['score_row22'], "int"),
                       GetSQLValueString($_POST['course_row23'], "text"),
                       GetSQLValueString($_POST['score_row23'], "int"),
                       GetSQLValueString($_POST['course_row24'], "text"),
                       GetSQLValueString($_POST['score_row24'], "int"),
                       GetSQLValueString($_POST['hiddenField'], "int"));

  mysql_select_db($database_nti_ca, $nti_ca);
  $Result1 = mysql_query($updateSQL, $nti_ca) or die(mysql_error());

  $updateGoTo = "C1BUpdateSuccess.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_C1BupdatePesIrs = "-1";
if (isset($_GET['admission_no'])) {
  $colname_C1BupdatePesIrs = $_GET['admission_no'];
}
mysql_select_db($database_nti_ca, $nti_ca);
$query_C1BupdatePesIrs = sprintf("SELECT * FROM c1secondsemesterpesirs WHERE admission_no = %s", GetSQLValueString($colname_C1BupdatePesIrs, "text"));
$C1BupdatePesIrs = mysql_query($query_C1BupdatePesIrs, $nti_ca) or die(mysql_error());
$row_C1BupdatePesIrs = mysql_fetch_assoc($C1BupdatePesIrs);
$totalRows_C1BupdatePesIrs = mysql_num_rows($C1BupdatePesIrs);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="shortcut icon" href="../../../images/icon.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>National Teachers' Institute, Kaduna</title>
<link href="../../../style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="menu">
      <ul>
        <li><a href="../../../index.html" class="current_page_item">HOME</a></li>
        <li><a href="../../../tutor_login.php" class="current_page_item">TUTOR LOGIN</a></li>
        <li><a href="../../../admin_login.php" class="current_page_item">ADMIN</a></li>
        <li><a href="../../../contact.php" class="current_page_item">CONTACT</a></li>
      </ul>
</div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo"></div>
	</div>
	<!-- end #header -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="content">
		  <h1 class="title" align="center"><strong><font color="#FFF">Welcome to National Teachers' Institute Student Data Collection Site</font></strong></h1>
		  <div class="current_page_item" id="calendar_wrap">
<p align="justify"><strong><font color="#FFF"><a href="C1B.php">GO BACK...</a></font></strong> </p>
<form action="<?php echo $editFormAction; ?>" method="post" id="form1">
  <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $row_C1BupdatePesIrs['id']; ?>" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Admission No:</td>
                  <td>&nbsp;</td>
                  <td><input name="admission_no" type="text" value="<?php echo $row_C1BupdatePesIrs['admission_no']; ?>" size="15" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Student Name:</td>
                  <td>&nbsp;</td>
                  <td><input name="full_name" type="text" value="<?php echo $row_C1BupdatePesIrs['full_name']; ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study State:</td>
                  <td>&nbsp;</td>
                  <td><input name="study_state" type="text" value="<?php echo $row_C1BupdatePesIrs['study_state']; ?>" size="15" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Study Center:</td>
                  <td>&nbsp;</td>
                  <td><input name="study_center" type="text" value="<?php echo $row_C1BupdatePesIrs['study_center']; ?>" size="60" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Course:</td>
                  <td>&nbsp;</td>
                  <td><input name="course" type="text" value="<?php echo $row_C1BupdatePesIrs['course']; ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Semester:</td>
                  <td>&nbsp;</td>
                  <td><input name="semester" type="text" value="<?php echo $row_C1BupdatePesIrs['semester']; ?>" size="32" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">Level:</td>
                  <td>&nbsp;</td>
                  <td><input name="level" type="text" value="<?php echo $row_C1BupdatePesIrs['level']; ?>" size="10" readonly="readonly" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right" id="course_row26" name="course_row1" value="EDU-101">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                </table>
                  <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td colspan="3" align="center" id="course_row25" name="course_row1" value="EDU-101"><strong>EDUCATION COURSES</strong></td>
                </tr>
                <tr valign="baseline">
                  <td align="right" id="course_row1" name="course_row1" value="EDU-101">
                  <input name="course_row1" type="text" id="course_row1" title="EDU-101: Historical Foundation of Education"  value="EDU-101" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td>
                  <input name="score_row1" type="text" id="score_row1" value="<?php echo $row_C1BupdatePesIrs['score_row1']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row2" type="text" id="course_row2" title="EDU-102: Sociological Foundation of Education" value="EDU-102" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row2" type="text" id="score_row2" value="<?php echo $row_C1BupdatePesIrs['score_row2']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row3" type="text" id="course_row3" title="EDU-111: Educational Psychology: Child Development I" value="EDU-111" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row3" type="text" id="score_row3" value="<?php echo $row_C1BupdatePesIrs['score_row3']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row4" type="text" id="course_row4" title="EDU-112: Educational Psychology: Child Development II" value="EDU-112" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row4" type="text" id="score_row4" value="<?php echo $row_C1BupdatePesIrs['score_row4']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row5" type="text" id="course_row5" title="EDU-113: Educational Psychology: Child Development III" value="EDU-113" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row5" type="text" id="score_row5" value="<?php echo $row_C1BupdatePesIrs['score_row5']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row6" type="text" id="course_row6" title="EDU-123: General Principle and Method I" value="EDU-123" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row6" type="text" id="score_row6" value="<?php echo $row_C1BupdatePesIrs['score_row6']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row7" type="text" id="course_row7" title="EDU-124: General Principle and Method II" value="EDU-124" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row7" type="text" id="score_row7" value="<?php echo $row_C1BupdatePesIrs['score_row7']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row8" type="text" id="course_row8" title="EDU-125: General Principles & Methodology of Teaching III" value="EDU-125" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row8" type="text" id="score_row8" value="<?php echo $row_C1BupdatePesIrs['score_row8']; ?>" size="5" /></td>
                </tr>
                </table>
                  <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td colspan="3" align="center">&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="center"><strong>GENERAL STUDIES EDUCATION COURSES</strong></td>
                  </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row9" type="text" id="course_row9" title="GSE-101: Oracy Skills" value="GSE-101" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row9" type="text" id="score_row9" value="<?php echo $row_C1BupdatePesIrs['score_row9']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row10" type="text" id="course_row10" title="GSE-102: English Language Usage" value="GSE-102" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row10" type="text" id="score_row10" value="<?php echo $row_C1BupdatePesIrs['score_row10']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row11" type="text" id="course_row11" title="GSE-103: Advanced Reading Skills" value="GSE-103" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row11" type="text" id="score_row11" value="<?php echo $row_C1BupdatePesIrs['score_row11']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row12" type="text" id="course_row12" title="GSE-104: Advanced Writing Skills" value="GSE-104" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row12" type="text" id="score_row12" value="<?php echo $row_C1BupdatePesIrs['score_row12']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row13" type="text" id="course_row13" title="GSE-105: Citizenship Education" value="GSE-105" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row13" type="text" id="score_row13" value="<?php echo $row_C1BupdatePesIrs['score_row13']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row14" type="text" id="course_row14" title="GSE-106: Political Economy" value="GSE-106" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row14" type="text" id="score_row14" value="<?php echo $row_C1BupdatePesIrs['score_row14']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row15" type="text" id="course_row15" title="GSE-111: Introduction to Computer Studies" value="GSE-111" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row15" type="text" id="score_row15" value="<?php echo $row_C1BupdatePesIrs['score_row15']; ?>" size="5" /></td>
                </tr>
                </table>
                <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="center"><strong>PRIMARY EDUCATION STUDIES COURSES</strong></td>
                  </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row16" type="text" id="course_row16" title="PES-111: His. & Cultural Background of the Immediate Env." value="PES-111" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row16" type="text" id="score_row16" value="<?php echo $row_C1BupdatePesIrs['score_row16']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row17" type="text" id="course_row17" title="PES-112: Drawing, Cultural and Creative Arts" value="PES-112" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row17" type="text" id="score_row17" value="<?php echo $row_C1BupdatePesIrs['score_row17']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row18" type="text" id="course_row18" title="PES-121: Primary Science Curriculum and Methods" value="PES-121" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row18" type="text" id="score_row18" value="<?php echo $row_C1BupdatePesIrs['score_row18']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row19" type="text" id="course_row19" title="PES-141: Number and Operations I" value="PES-141" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row19" type="text" id="score_row19" value="<?php echo $row_C1BupdatePesIrs['score_row19']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row20" type="text" id="course_row20" title="PES-142: Number and Operations II" value="PES-142" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row20" type="text" id="score_row20" value="<?php echo $row_C1BupdatePesIrs['score_row20']; ?>" size="5" /></td>
                </tr>
                </table>
                <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr valign="baseline">
                  <td colspan="3" align="center"><strong>ISLAMIC RELIGIOUS STUDIES COURSES</strong></td>
                  </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row21" type="text" id="course_row21" title="IRS-155: Islamic History" value="IRS-155" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row21" type="text" id="score_row21" value="<?php echo $row_C1BupdatePesIrs['score_row21']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row22" type="text" id="course_row22" title="IRS-175: Arabic I" value="IRS-175" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row22" type="text" id="score_row22" value="<?php echo $row_C1BupdatePesIrs['score_row22']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row23" type="text" id="course_row23" title="IRS-147: Purification/Prayer" value="IRS-147" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row23" type="text" id="score_row23" value="<?php echo $row_C1BupdatePesIrs['score_row23']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right"><input name="course_row24" type="text" id="course_row24" title="IRS-188: Methodology" value="IRS-188" size="5" readonly="readonly" /></td>
                  <td>&nbsp;</td>
                  <td><input name="score_row24" type="text" id="score_row24" value="<?php echo $row_C1BupdatePesIrs['score_row24']; ?>" size="5" /></td>
                </tr>
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                </table>
                <table align="center" cellpadding="3">
                <tr valign="baseline">
                  <td align="right">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input name="button" type="submit" class="Text_Field" id="button" value="Save Result" /> <input name="button2" type="reset" class="Text_Field" id="button2" value="Reset" /></td>
                </tr>
              </table>
  <p>
    <input type="hidden" name="MM_update" value="form1" />
    <input type="hidden" name="admission_no" value="<?php echo $row_C1BupdatePesIrs['admission_no']; ?>" />
  </p>
</form>
<p>&nbsp;</p>

<p align="justify">&nbsp;</p>
          </div>
		</div>
		<!-- end #content -->
<div id="sidebar">
			<ul>
				<li>
					<div id="search" >
					<form method="get" action="#">
						<div>
							<input type="text" name="s" id="search-text" value="" />
							<input type="submit" id="search-submit" value="" />
						</div>
					</form>
					</div>
					<div style="clear: both;">&nbsp;</div>
				<li>
					<h2>Rules for Data Entering</h2>
					<p><a href="#">&bull; Rules.....</a><a href="#"></a><br />
				  </p>
				</li>
			</ul>
</div>
<div id="sidebar1">
	    <blockquote>
	      <h1><font color="#FF3300"><i>News and Events</i></font></h1><br />
	      <p align="justify"><marquee direction="up" scrollamount="2" scrolldelay="50">
	          <font color="#990000"><b>NEWS AND EVENT HERE</b></font><br />
News and event here. <a href="#">Read-More...</a>
	      </marquee> 
	      _____________________________
	      <p>&nbsp;</p>
	    </blockquote>
      </div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<div id="footer">
		<p>Copyright (c) 2017 All rights reserved.<br />
		NTI - KADUNA<br /></p>
	</div>
	<!-- end #footer -->
</body>
</html>
<?php
mysql_free_result($C1BupdatePesIrs);
?>
